# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
"""LDM - Linux Download Manager."""
__version__ = "1.7.0"
__author__ = "SL_Linux"
__copyright__ = "Copyright (C) 2026 SL_Linux"
