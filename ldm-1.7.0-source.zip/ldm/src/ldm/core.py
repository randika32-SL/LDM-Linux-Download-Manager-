# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
"""LDM core: multi-connection download engine, settings and queue manager."""
import glob
import hashlib
import io
import json
import mimetypes
import os
import platform
import re
import shutil
import signal
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile

UA = "Mozilla/5.0 (X11; Linux x86_64) LDM/1.0"
CHUNK = 64 * 1024
INF = 1 << 62
MIN_SPLIT = 256 * 1024          # never split a segment smaller than 2x this
SOCKET_TIMEOUT = 15

# Where LDM is installed: <prefix>/share/ldm/lib/ldm/core.py  ->  share dir and prefix.
SHARE_DIR = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
PREFIX = os.path.abspath(os.path.join(SHARE_DIR, "..", ".."))


def _first_existing(paths, default):
    return next((p for p in paths if os.path.exists(p)), default)


HOST_PATH = _first_existing([os.path.join(PREFIX, "lib", "ldm", "ldm-native-host"),
                             os.path.join(SHARE_DIR, "libexec", "ldm-native-host")],
                            os.path.join(PREFIX, "lib", "ldm", "ldm-native-host"))
EXT_DIR = os.path.join(SHARE_DIR, "extension")
LAUNCHER = _first_existing([os.path.join(PREFIX, "bin", "ldm"), os.path.join(SHARE_DIR, "bin", "ldm")], "ldm")

CONFIG_DIR = os.path.join(
    os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config"), "ldm")
DATA_DIR = os.path.join(
    os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share"), "ldm")
INBOX_DIR = os.path.join(DATA_DIR, "inbox")      # browser captures land here
CHROME_EXT_ID = "lkjbfjmpcfindeedpcadfhblcdnjkhib"   # fixed by the key in the extension manifest
BIN_DIR = os.path.join(DATA_DIR, "bin")          # yt-dlp / deno managed by LDM
LOG_PATH = os.path.join(DATA_DIR, "ldm.log")

CATEGORIES = {
    "Compressed": {"zip", "rar", "7z", "tar", "gz", "gzip", "iso", "img", "msi", "exe",
                   "tgz", "bz2", "xz", "zst", "cab"},
    "Documents": {"doc", "docx", "pdf", "ppt", "pptx", "xls", "xlsx", "txt",
                  "odt", "ods", "odp", "epub", "rtf", "csv", "djvu", "mobi"},
    "Music": {"mp3", "wav", "wma", "aac", "m4a", "ogg", "aif", "aiff", "aifc",
              "opus", "flac", "mid"},
    "Programs": {"deb", "rpm", "appimage", "apk", "sh", "run", "dmg", "bin", "flatpakref", "snap"},
    "Video": {"mp4", "mkv", "avi", "mov", "flv", "wmv", "webm", "3gp", "m4v", "ts", "mpg", "mpeg"},
}
CATEGORY_NAMES = list(CATEGORIES) + ["General"]


def category_for(filename):
    ext = os.path.splitext(filename)[1].lstrip(".").lower()
    for name, exts in CATEGORIES.items():
        if ext in exts:
            return name
    return "General"


# ----------------------------------------------------------------- formatting
def fmt_size(n):
    if n is None or n < 0:
        return "Unknown"
    n = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.2f} TB"


def fmt_rate(bps):
    return "" if not bps or bps < 1 else fmt_size(bps) + "/sec"


def fmt_eta(sec):
    if sec is None or sec < 0:
        return ""
    sec = int(sec)
    if sec < 60:
        return f"{sec} sec"
    if sec < 3600:
        return f"{sec // 60} min {sec % 60} sec"
    if sec < 86400:
        return f"{sec // 3600} h {(sec % 3600) // 60} min"
    return f"{sec // 86400} d {(sec % 86400) // 3600} h"


def fmt_time(ts):
    return time.strftime("%b %d %H:%M:%S", time.localtime(ts)) if ts else ""


# ------------------------------------------------------------------- settings
def default_download_dir():
    """The user's Downloads folder, honouring localized names (XDG user directories)."""
    home = os.path.expanduser("~")
    cfg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    try:
        with open(os.path.join(cfg, "user-dirs.dirs")) as f:
            for line in f:
                m = re.match(r'\s*XDG_DOWNLOAD_DIR\s*=\s*"?([^"\n]+)"?', line)
                if m:
                    p = m.group(1).replace("$HOME", home)
                    if os.path.isabs(p) and os.path.normpath(p) != os.path.normpath(home):
                        return p
    except OSError:
        pass
    return os.path.join(home, "Downloads")


DEFAULTS = {
    "connections": 8,
    "max_active": 3,
    "download_dir": default_download_dir(),
    "categorize": True,
    "speed_limit_kb": 0,
    "show_progress": True,
    "capture_dialog": True,
    "video_cookies": "",
    "keep_running": True,
}


class Settings(dict):
    path = os.path.join(CONFIG_DIR, "settings.json")

    def __init__(self):
        super().__init__(DEFAULTS)
        try:
            with open(self.path) as f:
                self.update({k: v for k, v in json.load(f).items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass

    def save(self):
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(self.path, "w") as f:
            json.dump(dict(self), f, indent=2)


# ---------------------------------------------------------------------- utils
def log_event(text):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(LOG_PATH, "a") as f:
            f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + text.replace("\n", " ") + "\n")
    except OSError:
        pass


class HttpStatus(OSError):
    def __init__(self, code, reason=""):
        super().__init__(f"HTTP {code} {reason}".strip())
        self.code = code


def safe_name(name):
    name = name.replace("\x00", "")
    name = re.sub(r'[\\/:*?"<>|\r\n\t]', "_", name).strip(" .")
    return name[:200] or "download"


def name_from_url(url):
    path = urllib.parse.urlsplit(url).path
    return safe_name(urllib.parse.unquote(os.path.basename(path))) if path.strip("/") else "download"


def name_from_headers(headers, url):
    cd = headers.get("Content-Disposition", "") or ""
    name = None
    m = re.search(r"filename\*\s*=\s*([^']*)'[^']*'([^;]+)", cd, re.I)
    if m:
        try:
            name = urllib.parse.unquote(m.group(2).strip(), encoding=m.group(1) or "utf-8")
        except LookupError:
            name = urllib.parse.unquote(m.group(2).strip())
    else:
        m = (re.search(r'filename\s*=\s*"([^"]+)"', cd, re.I)
             or re.search(r"filename\s*=\s*([^;]+)", cd, re.I))
        if m:
            name = m.group(1).strip()
    return safe_name(name) if name else name_from_url(url)


def unique_name(directory, name):
    base, ext = os.path.splitext(name)
    if base.lower().endswith(".tar"):
        base, ext = base[:-4], ".tar" + ext
    cand, i = name, 1
    while (os.path.exists(os.path.join(directory, cand))
           or os.path.exists(os.path.join(directory, cand + ".ldm"))):
        cand = f"{base} ({i}){ext}"
        i += 1
    return cand


class _Redirect(urllib.request.HTTPRedirectHandler):
    """Never forward cookies or credentials to a different host on redirect."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        new = super().redirect_request(req, fp, code, msg, headers, newurl)
        if new is not None and (urllib.parse.urlsplit(newurl).netloc.lower()
                                != urllib.parse.urlsplit(req.full_url).netloc.lower()):
            for h in ("Cookie", "Authorization"):
                new.headers.pop(h, None)
                new.unredirected_hdrs.pop(h, None)
        return new


OPENER = urllib.request.build_opener(_Redirect())


def probe(url, referer="", cookie="", ua=""):
    """Ask the server about the file. Uses a 1-byte ranged GET, which works
    on servers that reject HEAD."""
    headers = {"User-Agent": ua or UA, "Range": "bytes=0-0", "Accept-Encoding": "identity"}
    if referer:
        headers["Referer"] = referer
    if cookie:
        headers["Cookie"] = cookie
    req = urllib.request.Request(url, headers=headers)
    try:
        with OPENER.open(req, timeout=20) as r:
            cr = r.headers.get("Content-Range")
            if r.status == 206 and cr and "/" in cr and not cr.endswith("/*"):
                size, resumable = int(cr.rsplit("/", 1)[1]), True
            else:
                cl = r.headers.get("Content-Length")
                size = int(cl) if cl and cl.isdigit() else -1
                resumable = False
            return {"size": size, "resumable": resumable, "ctype": r.headers.get_content_type(),
                    "name": name_from_headers(r.headers, r.geturl())}
    except urllib.error.HTTPError as e:
        if e.code == 416:      # empty file
            return {"size": 0, "resumable": False, "ctype": "", "name": name_from_url(url)}
        raise HttpStatus(e.code, e.reason)
    except urllib.error.URLError as e:
        raise IOError(str(e.reason))


# ------------------------------------------------------- video (yt-dlp) support
VIDEO_HOSTS = ("youtube.com", "youtu.be", "youtube-nocookie.com", "vimeo.com", "dailymotion.com",
               "twitch.tv", "tiktok.com", "soundcloud.com", "bilibili.com", "x.com",
               "twitter.com", "facebook.com", "fb.watch", "instagram.com", "reddit.com")
QUALITIES = {
    "Up to 1080p": "bv*[height<=1080]+ba/b[height<=1080]/bv*+ba/b",
    "Best available": "bv*+ba/b",
    "Up to 720p": "bv*[height<=720]+ba/b[height<=720]/bv*+ba/b",
    "Up to 480p": "bv*[height<=480]+ba/b[height<=480]/bv*+ba/b",
    "Up to 360p": "bv*[height<=360]+ba/b[height<=360]/bv*+ba/b",
    "Audio only (original)": "ba/b",
    "Audio only (MP3)": "ba/b",
}
AUDIO_QUALITIES = ("Audio only (original)", "Audio only (MP3)")
DEFAULT_QUALITY = "Up to 1080p"


def format_for(quality):
    if quality in QUALITIES:
        return QUALITIES[quality]
    m = re.fullmatch(r"Up to (\d{3,4})p", quality or "")
    if m:
        h = m.group(1)
        return f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b"
    return QUALITIES[DEFAULT_QUALITY]


def _fsize(f):
    return (f.get("filesize") or f.get("filesize_approx") or None) if f else None


def summarize_formats(info):
    """Turn yt-dlp's format list into a short menu: one entry per resolution + audio."""
    fmts = info.get("formats") or []
    audio = [f for f in fmts if f.get("vcodec") in (None, "none") and f.get("acodec") not in (None, "none")]
    best_a = max(audio, key=lambda f: (f.get("abr") or f.get("tbr") or 0), default=None)
    a_size = _fsize(best_a)
    by_h = {}

    def score(x):
        return ((x.get("ext") == "mp4") * 2 + str(x.get("vcodec") or "").startswith("avc"),
                x.get("tbr") or 0)
    for f in fmts:
        if f.get("vcodec") == "none" or not f.get("height"):       # None = codec simply not stated
            continue
        h = int(f["height"])
        if h not in by_h or score(f) > score(by_h[h]):
            by_h[h] = f
    items = []
    for h in sorted(by_h, reverse=True):
        f = by_h[h]
        size = _fsize(f)
        if not size and f.get("tbr") and info.get("duration"):      # HLS: estimate from bitrate
            size = int(f["tbr"] * 125 * info["duration"])
        if size and f.get("acodec") == "none" and a_size:           # video-only: add its audio
            size += a_size
        fps = f.get("fps")
        items.append({"label": f"{h}p" + (f"{int(fps)}" if fps and fps > 30 else ""),
                      "quality": f"Up to {h}p", "size": size})
    if not items:
        items.append({"label": "Best available", "quality": "Best available", "size": _fsize(info)})
    items.append({"label": "Audio only", "quality": "Audio only (original)", "size": a_size})
    items.append({"label": "Audio only (MP3)", "quality": "Audio only (MP3)", "size": a_size})
    return items


STREAM_CTYPES = {"application/vnd.apple.mpegurl", "application/x-mpegurl", "audio/mpegurl",
                 "audio/x-mpegurl", "application/dash+xml"}


def is_stream_url(url):
    return urllib.parse.urlsplit(url or "").path.lower().endswith((".m3u8", ".mpd"))


def clean_text(v, n):
    return re.sub(r"[\x00-\x1f\x7f]", "", str(v or ""))[:n]


QUALITY_RE = re.compile(r"^(Up to \d{3,4}p|Best available|Audio only \((original|MP3)\))$")


def valid_http_url(u):
    p = urllib.parse.urlsplit(u or "")
    return p.scheme in ("http", "https") and bool(p.netloc)


def write_inbox(msg):
    """Queue a link coming from the browser extension for the running LDM window."""
    url = str(msg.get("url", ""))
    if not valid_http_url(url):
        return False
    q = str(msg.get("quality", ""))
    ref = clean_text(msg.get("referer"), 2048)
    data = {"url": url, "referer": ref if valid_http_url(ref) else "",
            "cookie": str(msg.get("cookie", ""))[:8192],
            "kind": "video" if msg.get("kind") == "video" else "",
            "quality": q if QUALITY_RE.match(q) else "",
            "ua": clean_text(msg.get("ua"), 512), "title": clean_text(msg.get("title"), 200)}
    os.makedirs(INBOX_DIR, mode=0o700, exist_ok=True)
    name = uuid.uuid4().hex
    tmp = os.path.join(INBOX_DIR, name + ".tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)      # may contain cookies
    with os.fdopen(fd, "w") as f:
        json.dump(data, f)
    os.replace(tmp, os.path.join(INBOX_DIR, name + ".json"))
    return True


def parse_ldm_link(link):
    """ldm://add?url=...&kind=video&quality=...  ->  dict (or None)."""
    p = urllib.parse.urlsplit(link)
    if p.scheme != "ldm":
        return None
    q = {k: v[0] for k, v in urllib.parse.parse_qs(p.query).items()}
    qual = q.get("quality", "")
    return {"action": (p.netloc or p.path.strip("/")).lower(), "url": q.get("url", ""),
            "referer": q.get("referer", ""), "kind": "video" if q.get("kind") == "video" else "",
            "quality": qual if QUALITY_RE.match(qual) else ""}


def _header_args(referer, ua):
    """Send yt-dlp the same Referer/Origin/User-Agent the browser used (embed hosts check them)."""
    args = []
    referer, ua = clean_text(referer, 2048), clean_text(ua, 512)
    if valid_http_url(referer):
        o = urllib.parse.urlsplit(referer)
        args += ["--referer", referer, "--add-header", f"Origin:{o.scheme}://{o.netloc}"]
    if ua:
        args += ["--user-agent", ua]
    return args


def list_formats(url, referer="", ua=""):
    """Ask yt-dlp which qualities a video offers (one entry per resolution)."""
    exe = find_ytdlp()
    if not exe:
        return {"ok": False, "need_install": True,
                "error": "Video downloader not installed. In LDM: Tasks > Install video downloader."}
    cmd = [exe, "--no-playlist", "-J", "--no-warnings", "--remote-components", "ejs:github"]
    cmd += js_runtime_args() + _header_args(referer, ua) + ["--", url]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "Timed out reading the video information"}
    if r.returncode != 0:
        errs = [ln for ln in r.stderr.splitlines() if ln.startswith("ERROR")]
        return {"ok": False, "error": (errs[-1] if errs else "Could not read this video")[:200]}
    try:
        info = json.loads(r.stdout)
    except ValueError:
        return {"ok": False, "error": "Unexpected response from the video downloader"}
    return {"ok": True, "title": str(info.get("title", ""))[:120], "items": summarize_formats(info)}


def is_video_page(url):
    host = (urllib.parse.urlsplit(url).hostname or "").lower()
    return any(host == h or host.endswith("." + h) for h in VIDEO_HOSTS)


def find_tool(name):
    p = os.path.join(BIN_DIR, name)
    if os.path.isfile(p) and os.access(p, os.X_OK):
        return p
    return shutil.which(name)


def find_ytdlp():
    return find_tool("yt-dlp")


def js_runtime_args():
    """YouTube needs a JavaScript runtime; prefer Deno, then Node, Bun, QuickJS."""
    for exe, name in (("deno", "deno"), ("node", "node"), ("bun", "bun"), ("qjs", "quickjs")):
        p = find_tool(exe)
        if p:
            return ["--js-runtimes", f"{name}:{p}"]
    return []


def video_tools_status():
    """-> list of human-readable problems (empty = ready)."""
    problems = []
    if not find_ytdlp():
        problems.append("yt-dlp (video extractor)")
    if not js_runtime_args():
        problems.append("a JavaScript runtime (Deno)")
    if not find_tool("ffmpeg"):
        problems.append("ffmpeg (needed to merge video and audio: sudo apt install ffmpeg)")
    return problems


def _get(url, timeout=60):
    return urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": UA}),
                                  timeout=timeout)


def _verified(url, expected_sha, timeout=300):
    data = _get(url, timeout).read()
    if hashlib.sha256(data).hexdigest() != expected_sha.lower():
        raise IOError("Checksum mismatch for " + url.rsplit("/", 1)[-1])
    return data


def install_video_tools(log=print):
    """Download yt-dlp (and Deno if no JS runtime exists) from their official GitHub
    releases into LDM's own folder, verifying SHA-256 checksums. Safe to re-run to update."""
    os.makedirs(BIN_DIR, exist_ok=True)
    mach = platform.machine()
    musl = any(n.startswith("ld-musl") for n in (os.listdir("/lib") if os.path.isdir("/lib") else []))
    asset = ({"x86_64": "yt-dlp_musllinux", "aarch64": "yt-dlp_musllinux_aarch64"} if musl else
             {"x86_64": "yt-dlp_linux", "aarch64": "yt-dlp_linux_aarch64"}).get(mach, "yt-dlp")
    base = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/"
    log("Downloading yt-dlp...")
    sums = {}
    for line in _get(base + "SHA2-256SUMS").read().decode().splitlines():
        parts = line.split()
        if len(parts) == 2:
            sums[parts[1].lstrip("*")] = parts[0]
    if asset not in sums:
        raise IOError("No checksum published for " + asset)
    data = _verified(base + asset, sums[asset])
    tmp = os.path.join(BIN_DIR, "yt-dlp.tmp")
    with open(tmp, "wb") as f:
        f.write(data)
    os.chmod(tmp, 0o755)
    os.replace(tmp, os.path.join(BIN_DIR, "yt-dlp"))
    if not js_runtime_args():
        triple = {"x86_64": "x86_64-unknown-linux-gnu",
                  "aarch64": "aarch64-unknown-linux-gnu"}.get(mach)
        if not triple or musl:
            raise IOError("Deno has no build for this system. Install nodejs from your package "
                          "manager (needed for YouTube), then run this again.")
        log("Downloading Deno (JavaScript runtime needed for YouTube)...")
        url = f"https://github.com/denoland/deno/releases/latest/download/deno-{triple}.zip"
        sha = _get(url + ".sha256sum").read().decode().split()[0]
        z = zipfile.ZipFile(io.BytesIO(_verified(url, sha)))
        tmp = os.path.join(BIN_DIR, "deno.tmp")
        with open(tmp, "wb") as f:
            f.write(z.read("deno"))
        os.chmod(tmp, 0o755)
        os.replace(tmp, os.path.join(BIN_DIR, "deno"))
    log("Done.")


class Seg:
    __slots__ = ("start", "end", "pos", "busy")

    def __init__(self, start, end, pos):
        self.start, self.end, self.pos = start, end, pos
        self.busy = False

    @property
    def done(self):
        return self.pos > self.end


# ------------------------------------------------------------------- Download
class Download:
    def __init__(self, url, base_dir, filename=None, connections=8,
                 description="", referer="", categorize=True, cookie="", kind="http", quality="",
                 ua="", title=""):
        self.id = uuid.uuid4().hex[:10]
        self.url, self.referer, self.description = url, referer, description
        self.cookie = cookie
        self.base_dir = self.directory = base_dir
        self.name_fixed = bool(filename)
        self.kind, self.quality = kind, quality
        self.ua, self.title_hint, self.out_base = ua, title, ""
        self.filename = (safe_name(filename) if filename else
                         "Resolving video..." if kind == "ytdlp" else name_from_url(url))
        self.categorize = categorize
        self.connections = max(1, int(connections))
        self.size, self.resumable, self.probed = -1, False, False
        self.status, self.error = "Paused", ""
        self.added, self.last_try, self.completed = time.time(), 0, 0
        self.segments = []
        self.speed = 0.0
        self.limit_bps = 0
        self.from_queue = False
        self.cookies_browser = ""
        self._logged = ""
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = None
        self._next = 0.0

    # -- persistence
    KEYS = ("id", "url", "referer", "description", "base_dir", "directory", "name_fixed",
            "filename", "categorize", "connections", "cookie", "kind", "quality", "ua", "title_hint", "out_base", "size", "resumable", "probed",
            "status", "error", "added", "last_try", "completed")

    def to_dict(self):
        d = {k: getattr(self, k) for k in self.KEYS}
        d["segments"] = [[s.start, s.end, s.pos] for s in self.segments]
        return d

    @classmethod
    def from_dict(cls, d):
        o = cls(d["url"], d["base_dir"])
        for k in cls.KEYS:
            if k in d:
                setattr(o, k, d[k])
        o.segments = [Seg(*s) for s in d.get("segments", [])]
        if o.status in ("Downloading", "Queued"):
            o.status = "Paused"
        return o

    # -- derived
    @property
    def path(self):
        return os.path.join(self.directory, self.filename)

    @property
    def tmp_path(self):
        return self.path + ".ldm"

    @property
    def category(self):
        if self.kind == "ytdlp" and self.status != "Complete":
            return "Music" if self.quality in AUDIO_QUALITIES else "Video"
        return category_for(self.filename)

    @property
    def downloaded(self):
        if self.status == "Complete":
            return max(self.size, 0)
        return sum(max(0, min(s.pos, s.end + 1) - s.start) for s in list(self.segments))

    @property
    def percent(self):
        if self.status == "Complete":
            return 100.0
        return min(100.0, self.downloaded * 100.0 / self.size) if self.size > 0 else 0.0

    @property
    def eta(self):
        if self.status != "Downloading" or self.size <= 0 or self.speed < 1:
            return None
        return (self.size - self.downloaded) / self.speed

    def is_active(self):
        return bool(self._thread and self._thread.is_alive())

    # -- control
    def begin(self):
        if self.status == "Complete" or (self.is_active() and not self._stop.is_set()):
            return
        prev = self._thread
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, args=(prev, self._stop), daemon=True)
        self.status, self.error = "Downloading", ""
        self._thread.start()

    def stop(self):
        self._stop.set()
        if self.status in ("Downloading", "Queued"):
            self.status = "Paused"
        self.speed = 0.0

    def cleanup(self, delete_final):
        """Remove files once any running worker has exited."""
        self.stop()
        prev, paths = self._thread, [self.tmp_path]
        if delete_final:
            paths.append(self.path)

        def job():
            if prev:
                prev.join()
            for p in paths:
                try:
                    os.remove(p)
                except OSError:
                    pass
        threading.Thread(target=job, daemon=True).start()

    def reset(self):
        """Forget progress so the file is fetched from scratch."""
        self.stop()
        prev, tmp = self._thread, self.tmp_path
        if prev:
            prev.join()
        try:
            os.remove(tmp)
        except OSError:
            pass
        self.segments, self.size, self.probed = [], -1, False
        if not self.name_fixed:
            self.filename = name_from_url(self.url)
        self.directory = self.base_dir
        self.status = "Paused"

    # -- internals
    def _throttle(self, n):
        if self.limit_bps <= 0:
            return
        with self._lock:
            now = time.monotonic()
            t = max(self._next, now)
            self._next = t + n / self.limit_bps
        if t > now:
            time.sleep(min(t - now, 2))

    def _run(self, prev, stop):
        if prev:
            prev.join()
        if stop.is_set():
            return
        self.last_try = time.time()
        try:
            if self.kind == "ytdlp":
                self._run_ytdlp(stop)
                return
            if not self.probed:
                info = None
                for attempt in range(3):
                    try:
                        info = probe(self.url, self.referer, self.cookie, self.ua)
                        break
                    except OSError as e:
                        if attempt == 2 or getattr(e, "code", None) in (401, 404, 410):
                            raise
                    stop.wait(1 + 2 * attempt)
                    if stop.is_set():
                        return
                stream = info["ctype"] in STREAM_CTYPES or is_stream_url(self.url)
                if stream or info["ctype"] in ("text/html", "application/xhtml+xml"):
                    if find_ytdlp():            # playlist or web page, not a file: use the video extractor
                        self.kind, self.quality = "ytdlp", self.quality or DEFAULT_QUALITY
                        self.filename = "Resolving video..."
                        self._run_ytdlp(stop)
                        return
                    raise IOError(("This is a streaming playlist (HLS/DASH), not a file. "
                                   if stream else "This address is a web page, not a file. ") +
                                  "For videos use Tasks > Install video downloader, then add the link again.")
                self.size, self.resumable = info["size"], info["resumable"]
                if not self.name_fixed:
                    self.filename = info["name"]
                    ct = info["ctype"]
                    if (not os.path.splitext(self.filename)[1] and ct
                            and ct != "application/octet-stream"):
                        self.filename += mimetypes.guess_extension(ct) or ""
                    if self.title_hint:         # name the file after the page/episode title
                        self.filename = (safe_name(self.title_hint)[:150]
                                         + os.path.splitext(self.filename)[1])
                self.directory = (os.path.join(self.base_dir, self.category)
                                  if self.categorize else self.base_dir)
                os.makedirs(self.directory, exist_ok=True)
                self.filename = unique_name(self.directory, self.filename)
                self.probed = True
            os.makedirs(self.directory, exist_ok=True)
            if not self.segments:
                self._make_segments()
            self._transfer(stop)
        except Exception as e:                     # noqa: BLE001
            if self._stop is stop:
                self.status, self.error, self.speed = "Error", str(e) or repr(e), 0.0

    def _run_ytdlp(self, stop):
        exe = find_ytdlp()
        if not exe:
            raise IOError("The video downloader is not installed. Use Tasks > Install video downloader.")
        audio = self.quality in AUDIO_QUALITIES
        self.probed = True
        self.directory = (os.path.join(self.base_dir, "Music" if audio else "Video")
                          if self.categorize else self.base_dir)
        os.makedirs(self.directory, exist_ok=True)
        cmd = [exe, "--no-playlist", "--newline", "--no-colors", "--no-warnings", "--progress",
               "--progress-template",
               "download:LDMP %(progress.downloaded_bytes|0)s %(progress.total_bytes|0)s "
               "%(progress.total_bytes_estimate|0)s %(progress.speed|0)s",
               "--print", "before_dl:LDMT %(title)s", "--print", "after_move:LDMF %(filepath)s",
               "-f", format_for(self.quality),
               "--retries", "10", "--fragment-retries", "10", "--extractor-retries", "3",
               "--socket-timeout", "30",
               "-S", "res,ext:mp4:m4a", "--merge-output-format", "mp4",
               "--concurrent-fragments", str(min(max(self.connections, 1), 16)),
               "--remote-components", "ejs:github"] + js_runtime_args()
        cookie_path = None
        if self.cookie:                          # login cookies sent by the browser extension
            cookie_path = self._write_cookie_file()
            cmd += ["--cookies", cookie_path]
        elif self.cookies_browser:
            cmd += ["--cookies-from-browser", self.cookies_browser]
        if self.quality == "Audio only (MP3)":
            cmd += ["-x", "--audio-format", "mp3"]
        if self.limit_bps > 0:
            cmd += ["--limit-rate", str(int(self.limit_bps))]
        cmd += _header_args(self.referer, self.ua)
        cmd += ["-o", self._out_template(), "--", self.url]
        try:
            self._ytdlp_loop(cmd, stop)
        finally:
            if cookie_path:
                try:
                    os.remove(cookie_path)
                except OSError:
                    pass

    def _out_template(self):
        """Output name: the page/episode title when the browser gave us one, else yt-dlp's title."""
        if not self.title_hint and is_stream_url(self.url):
            host = urllib.parse.urlsplit(self.url).hostname or "stream"
            self.title_hint = "Video from " + host + time.strftime(" %Y-%m-%d %H-%M-%S")
        if not self.title_hint:
            return os.path.join(self.directory, "%(title).150B [%(id)s].%(ext)s")
        if not self.out_base:                    # decided once, so a resumed download keeps its name
            stem, i, base = safe_name(self.title_hint)[:150], 1, ""
            base = stem
            while glob.glob(os.path.join(glob.escape(self.directory), glob.escape(base) + ".*")):
                base = f"{stem} ({i})"
                i += 1
            self.out_base = base
        return os.path.join(self.directory, self.out_base + ".%(ext)s")

    def _write_cookie_file(self):
        """Turn the 'a=1; b=2' header from the browser into a private Netscape cookie file."""
        host = urllib.parse.urlsplit(self.url).hostname or ""
        parts = host.split(".")
        domain = "." + ".".join(parts[-2:]) if len(parts) >= 2 else host
        lines = ["# Netscape HTTP Cookie File"]
        for pair in self.cookie.split(";"):
            if "=" in pair:
                k, v = pair.strip().split("=", 1)
                lines.append("\t".join([domain, "TRUE", "/", "TRUE", "2147483647", k, v]))
        folder = os.path.join(DATA_DIR, "tmp")
        os.makedirs(folder, mode=0o700, exist_ok=True)
        path = os.path.join(folder, self.id + ".cookies")
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write("\n".join(lines) + "\n")
        return path

    def _ytdlp_loop(self, cmd, stop):
        attempt = 0
        while True:
            rc, path, last_err, tail = self._ytdlp_once(cmd, stop)
            if self._stop is not stop:
                return
            self.speed = 0.0
            if rc == 0 and path and os.path.exists(path):
                self.directory, self.filename = os.path.dirname(path), os.path.basename(path)
                self.size = os.path.getsize(path)
                self.segments = [Seg(0, self.size - 1, self.size)] if self.size > 0 else []
                self.completed, self.status = time.time(), "Complete"
                return
            if stop.is_set():
                self.status = "Paused"
                return
            err = last_err or tail or f"yt-dlp exited with code {rc}"
            attempt += 1
            permanent = any(k in err for k in (
                "Unsupported URL", "Private video", "Video unavailable", "Sign in", "confirm your age", "DRM",
                "ffmpeg", "members-only", "Requested format is not available", "not installed"))
            if permanent or attempt >= 3:
                self.status = "Error"
                self.error = ("No downloadable video was found on this page."
                              if "Unsupported URL" in err else
                              "This stream uses DRM copy protection, which LDM does not support."
                              if "DRM" in err else err)
                return
            stop.wait(2 * attempt)            # transient failure: try again automatically
            if stop.is_set():
                self.status = "Paused"
                return

    def _ytdlp_once(self, cmd, stop):
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                errors="replace", bufsize=1, start_new_session=True)

        def watch():
            while proc.poll() is None:
                if stop.wait(0.3):
                    try:
                        os.killpg(proc.pid, signal.SIGTERM)
                    except OSError:
                        pass
                    return
        threading.Thread(target=watch, daemon=True).start()

        base = last_dl = last_total = 0
        path, last_err, tail = None, "", ""
        for line in proc.stdout:
            line = line.rstrip()
            if line.startswith("LDMP "):
                try:
                    dl, tot, est, sp = [float(x) if x not in ("NA", "None") else 0.0
                                        for x in line.split()[1:5]]
                except ValueError:
                    continue
                if dl < last_dl:                 # a new stream (e.g. audio after video) began
                    base += last_total
                last_dl, last_total = dl, (tot or est or dl)
                size, pos = int(base + last_total), int(base + dl)
                if self._stop is stop:
                    self.size = size
                    self.segments = [Seg(0, size - 1, min(pos, size))] if size > 0 else []
                    self.speed = sp
            elif line.startswith("LDMT "):
                if line[5:].strip() and not self.name_fixed and self._stop is stop:
                    self.filename = safe_name(line[5:])
            elif line.startswith("LDMF "):
                path = line[5:].strip()
            elif line.startswith("ERROR"):
                last_err = line
            elif line.strip():
                tail = line
        proc.wait()
        return proc.returncode, path, last_err, tail

    def _make_segments(self):
        s = self.size
        if s == 0:
            self.segments = []
        elif s > 0 and self.resumable and self.connections > 1:
            n = max(1, min(self.connections, s // (MIN_SPLIT * 2)))
            step = s // n
            self.segments = [Seg(i * step, s - 1 if i == n - 1 else (i + 1) * step - 1, i * step)
                             for i in range(n)]
        elif s > 0:
            self.segments = [Seg(0, s - 1, 0)]
        else:
            self.segments = [Seg(0, INF, 0)]

    def _transfer(self, stop):
        attempts, conns = 0, self.connections
        fd = os.open(self.tmp_path, os.O_RDWR | os.O_CREAT, 0o644)
        try:
            if self.size > 0 and os.fstat(fd).st_size != self.size:
                os.ftruncate(fd, self.size)
            while True:
                state = {"fail": None, "abort": False}
                pending = [s for s in self.segments if not s.done]
                for s in self.segments:
                    s.busy = False
                n = conns if (self.resumable and self.size > 0) else 1
                threads = []
                for i in range(n):
                    seg = pending[i] if i < len(pending) else None
                    if seg is not None:
                        seg.busy = True
                    t = threading.Thread(target=self._worker, args=(seg, fd, stop, state),
                                         daemon=True)
                    t.start()
                    threads.append(t)
                last_t, last_b, ema = time.monotonic(), self.downloaded, 0.0
                while any(t.is_alive() for t in threads):
                    time.sleep(0.4)
                    now, b = time.monotonic(), self.downloaded
                    inst = (b - last_b) / max(now - last_t, 1e-6)
                    ema = inst if ema == 0 else ema * 0.6 + inst * 0.4
                    last_t, last_b = now, b
                    if self._stop is stop:
                        self.speed = ema
                if self._stop is not stop:
                    return
                self.speed = 0.0
                if all(s.done for s in self.segments):
                    self._finish()
                    return
                if stop.is_set():
                    self.status = "Paused"
                    return
                attempts += 1
                f = state["fail"]
                if state["abort"] or attempts >= 4:
                    self.status = "Error"
                    self.error = (f"HTTP {f.code} {f.reason}" if isinstance(f, urllib.error.HTTPError)
                                  else str(f) if f else "Download incomplete")
                    return
                conns = max(1, conns // 2)    # server dislikes many connections: back off, retry
                stop.wait(2 * attempts)
                if stop.is_set():
                    self.status = "Paused"
                    return
        finally:
            os.close(fd)

    def _finish(self):
        total = sum(s.end - s.start + 1 for s in self.segments)
        if self.size < 0:
            self.size = total
        if self.size != total:
            self.status, self.error = "Error", "Size mismatch after download"
            return
        if not os.path.exists(self.tmp_path):
            open(self.tmp_path, "wb").close()
        if self.size >= 0:
            os.truncate(self.tmp_path, self.size)
        final = self.path
        if os.path.exists(final):
            self.filename = unique_name(self.directory, self.filename)
            final = self.path
        os.replace(self.tmp_path, final)
        self.completed = time.time()
        self.status = "Complete"

    def _steal(self):
        if not (self.resumable and self.size > 0):
            return None
        with self._lock:
            for s in self.segments:              # first adopt segments nobody is working on
                if not s.done and not s.busy:
                    s.busy = True
                    return s
            best, rem = None, 0
            for s in self.segments:
                r = s.end - s.pos + 1
                if r > rem:
                    best, rem = s, r
            if best is None or rem < 2 * MIN_SPLIT:
                return None
            mid = best.pos + rem // 2
            new = Seg(mid, best.end, mid)
            new.busy = True
            best.end = mid - 1
            self.segments.append(new)
            return new

    def _worker(self, seg, fd, stop, state):
        fails = 0
        try:
            while not stop.is_set() and not state["abort"]:
                if seg is None or seg.done:
                    seg = self._steal()
                    if seg is None:
                        return
                before = seg.pos
                try:
                    self._fetch(seg, fd, stop, state)
                    fails = 0
                except Exception as e:                 # noqa: BLE001
                    if stop.is_set():
                        return
                    state["fail"] = e
                    if isinstance(e, urllib.error.HTTPError) and e.code in (401, 404, 410):
                        state["abort"] = True
                        return
                    fails = 0 if seg.pos > before else fails + 1
                    if fails > 4:
                        return                         # give up this connection; others carry on
                    if not self.resumable:
                        with self._lock:
                            seg.pos = seg.start
                    stop.wait(min(2 ** fails, 10))
        finally:
            if seg is not None and not seg.done:
                seg.busy = False

    def _fetch(self, seg, fd, stop, state):
        headers = {"User-Agent": self.ua or UA, "Accept": "*/*", "Accept-Encoding": "identity"}
        if self.referer:
            headers["Referer"] = self.referer
        if self.cookie:
            headers["Cookie"] = self.cookie
        if self.resumable:
            headers["Range"] = f"bytes={seg.pos}-{seg.end}"
        req = urllib.request.Request(self.url, headers=headers)
        with OPENER.open(req, timeout=SOCKET_TIMEOUT) as r:
            if self.resumable and r.status != 206:
                raise IOError("Server stopped honouring range requests")
            while not stop.is_set() and not state["abort"]:
                with self._lock:
                    remaining = seg.end - seg.pos + 1
                if remaining <= 0:
                    return
                data = r.read(min(CHUNK, remaining))
                if not data:
                    if self.size < 0:              # unknown length: EOF means done
                        with self._lock:
                            seg.end = seg.pos - 1
                        return
                    raise IOError("Connection closed prematurely")
                self._throttle(len(data))
                with self._lock:
                    n = min(len(data), seg.end - seg.pos + 1)
                    if n <= 0:
                        return
                    os.pwrite(fd, data[:n], seg.pos)
                    seg.pos += n


# -------------------------------------------------------------------- Manager
class Manager:
    def __init__(self, settings):
        self.settings = settings
        self.downloads = []
        self.queue_running = False
        self._sig, self._last_save = None, 0
        self.store = os.path.join(DATA_DIR, "downloads.json")
        self.load()

    def load(self):
        try:
            with open(self.store) as f:
                self.downloads = [Download.from_dict(d) for d in json.load(f)]
        except (OSError, ValueError, KeyError):
            self.downloads = []

    def save(self):
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = self.store + ".tmp"
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)   # may hold cookies
        with os.fdopen(fd, "w") as f:
            json.dump([d.to_dict() for d in self.downloads], f)
        os.replace(tmp, self.store)

    def _limit(self):
        return int(self.settings["speed_limit_kb"]) * 1024

    def add(self, url, directory=None, filename=None, description="", connections=None,
            referer="", categorize=None, start=True, cookie="", kind="http", quality="",
            ua="", title=""):
        d = Download(url, directory or self.settings["download_dir"], filename,
                     connections or self.settings["connections"], description, referer,
                     self.settings["categorize"] if categorize is None else categorize,
                     cookie, kind, quality, ua, title)
        self.downloads.append(d)
        if start:
            self.start(d)
        else:
            d.status = "Queued"
        self.save()
        return d

    def start(self, d):
        if d.status == "Complete":
            return
        d.limit_bps, d.from_queue = self._limit(), False
        d.cookies_browser = self.settings["video_cookies"]
        d.begin()

    def stop(self, d):
        d.stop()

    def stop_all(self):
        for d in self.downloads:
            if d.status in ("Downloading", "Queued") or d.is_active():
                d.stop()

    def start_queue(self):
        self.queue_running = True

    def stop_queue(self):
        self.queue_running = False
        for d in self.downloads:
            if d.from_queue and d.status == "Downloading":
                d.stop()
                d.status = "Queued"

    def remove(self, d, delete_file=False):
        if d in self.downloads:
            self.downloads.remove(d)
        d.cleanup(delete_file and d.status == "Complete")
        self.save()

    def redownload(self, d):
        d.reset()
        self.start(d)

    def pump(self):
        active = sum(1 for d in self.downloads if d.status == "Downloading")
        if self.queue_running:
            for d in self.downloads:
                if active >= int(self.settings["max_active"]):
                    break
                if d.status == "Queued":
                    d.limit_bps, d.from_queue = self._limit(), True
                    d.cookies_browser = self.settings["video_cookies"]
                    d.begin()
                    active += 1
        for d in self.downloads:
            if d.status == "Error" and d._logged != d.error:
                d._logged = d.error
                log_event(f"ERROR {d.url} -> {d.error}")
        sig = tuple((d.id, d.status) for d in self.downloads)
        now = time.time()
        if sig != self._sig or now - self._last_save > 5:
            self._sig, self._last_save = sig, now
            try:
                self.save()
            except OSError:
                pass

    def shutdown(self):
        self.stop_all()
        for d in self.downloads:
            if d._thread:
                d._thread.join(timeout=2)
        try:
            self.save()
        except OSError:
            pass
