# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
import sys
from .app import main
sys.exit(main(sys.argv))
