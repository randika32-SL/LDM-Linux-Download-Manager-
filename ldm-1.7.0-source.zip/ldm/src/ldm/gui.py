# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
"""LDM GTK3 interface (classic download-manager layout)."""
import json
import os
import shutil
import subprocess
import threading
import urllib.parse

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk, Pango  # noqa: E402

from . import __version__, core  # noqa: E402

CAT_ICONS = {
    "Compressed": "package-x-generic", "Documents": "x-office-document",
    "Music": "audio-x-generic", "Programs": "application-x-executable",
    "Video": "video-x-generic", "General": "text-x-generic",
}

CSS = b"""
toolbar { padding: 2px 4px; border-bottom: 1px solid alpha(currentColor, 0.2); }
toolbar toolbutton button { padding: 4px 10px; }
treeview header button { font-weight: bold; }
.ldm-status { padding: 3px 8px; border-top: 1px solid alpha(currentColor, 0.2); }
"""


AUTOSTART = os.path.expanduser("~/.config/autostart/ldm.desktop")
HOST = core.HOST_PATH
EXT_DIR = core.EXT_DIR


def set_autostart(on):
    try:
        if on:
            os.makedirs(os.path.dirname(AUTOSTART), exist_ok=True)
            with open(AUTOSTART, "w") as f:
                f.write("[Desktop Entry]\nType=Application\nName=Linux Download Manager\n"
                        f"Exec={core.LAUNCHER} --background\nIcon=ldm\nX-GNOME-Autostart-enabled=true\n")
        elif os.path.exists(AUTOSTART):
            os.remove(AUTOSTART)
    except OSError:
        pass


class Tray:
    """Panel icon so a background LDM can be found again. Uses the modern AppIndicator when
    the system has it (GNOME with the extension, KDE, XFCE, ...), else the classic tray icon
    (Cinnamon, MATE, XFCE, ...). Where neither exists LDM still works; see notify_background()."""

    def __init__(self, win):
        self.win, self.icon, self.indicator = win, None, None
        if not self._try_indicator():
            self._try_status_icon()

    def _try_indicator(self):
        import importlib
        for ns in ("AyatanaAppIndicator3", "AppIndicator3"):
            try:
                gi.require_version(ns, "0.1")
                mod = importlib.import_module("gi.repository." + ns)
                ind = mod.Indicator.new("ldm", "ldm", mod.IndicatorCategory.APPLICATION_STATUS)
                ind.set_status(mod.IndicatorStatus.ACTIVE)
                ind.set_title("Linux Download Manager")
                ind.set_menu(self._build_menu())
                self.indicator = ind
                return True
            except Exception:                           # noqa: BLE001 - library missing or unusable
                continue
        return False

    def _try_status_icon(self):
        try:
            self.icon = Gtk.StatusIcon.new_from_icon_name("ldm")
            self.icon.set_tooltip_text("Linux Download Manager")
            self.icon.connect("activate", self.toggle)
            self.icon.connect("popup-menu", self.popup)
        except Exception:                               # noqa: BLE001 - no tray available
            self.icon = None

    def toggle(self, *_):
        if self.win.get_visible():
            self.win.hide()
        else:
            bring_to_front(self.win, hold_ms=2000)

    def _build_menu(self):
        m = Gtk.Menu()
        for label, cb in (("Show LDM", lambda: bring_to_front(self.win, hold_ms=2000)),
                          ("Add new download...", self.win.add_url),
                          ("Stop all", self.win.manager.stop_all), (None, None),
                          ("Exit", self.win.quit_app)):
            if label is None:
                m.append(Gtk.SeparatorMenuItem())
                continue
            mi = Gtk.MenuItem(label=label)
            mi.connect("activate", lambda _w, c=cb: c())
            m.append(mi)
        m.show_all()
        return m

    def popup(self, icon, button, time):
        m = self._build_menu()
        m.popup(None, None, Gtk.StatusIcon.position_menu, icon, button, time)


def open_path(path):
    """Open a file or folder with the desktop's default application."""
    try:
        if Gio.AppInfo.launch_default_for_uri(Gio.File.new_for_path(path).get_uri(), None):
            return
    except GLib.Error:
        pass
    try:                                                 # fallback when GIO finds no handler
        subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        pass


def reveal_file(path):
    """'Open folder' like a normal application: show the folder with the file selected."""
    if not os.path.exists(path):
        open_path(os.path.dirname(path) or ".")
        return
    uri = Gio.File.new_for_path(path).get_uri()
    try:
        bus = Gio.bus_get_sync(Gio.BusType.SESSION, None)

        def done(conn, res):
            try:
                conn.call_finish(res)
            except GLib.Error:                          # no file manager with this interface
                open_path(os.path.dirname(path))
        bus.call("org.freedesktop.FileManager1", "/org/freedesktop/FileManager1",
                 "org.freedesktop.FileManager1", "ShowItems", GLib.Variant("(ass)", ([uri], "")),
                 None, Gio.DBusCallFlags.NONE, 4000, None, done)
    except GLib.Error:
        open_path(os.path.dirname(path))


def _server_time(win):
    """A fresh X server timestamp, so the window manager accepts the raise request."""
    try:
        gi.require_version("GdkX11", "3.0")
        from gi.repository import GdkX11
        if win.get_window() is None:
            win.realize()
        gw = win.get_window()
        if isinstance(gw, GdkX11.X11Window):
            return GdkX11.x11_get_server_time(gw)
    except Exception:                                   # noqa: BLE001 - not X11 / no GdkX11
        pass
    return Gtk.get_current_event_time()


def center_window(win):
    """Centre a window (including its title bar) on the monitor where the pointer is."""
    try:
        gw = win.get_window()
        if gw is None:
            return False
        display = Gdk.Display.get_default()
        _scr, px, py = display.get_default_seat().get_pointer().get_position()
        mon = display.get_monitor_at_point(px, py) or display.get_primary_monitor()
        area = mon.get_workarea()
        fr = gw.get_frame_extents()
        win.move(area.x + (area.width - fr.width) // 2, area.y + (area.height - fr.height) // 2)
    except Exception:                                   # noqa: BLE001 - cosmetic only
        pass
    return False


def center_soon(win):
    """Centre now and again once the window has reached its final size."""
    for ms in (0, 120, 450):
        GLib.timeout_add(ms, center_window, win)


def bring_to_front(win, hold_ms=None):
    """Show a window above the browser even though the request did not come from a click in
    LDM (window managers refuse to hand focus to a window nobody clicked)."""
    try:
        win.deiconify()
        win.set_keep_above(True)                        # stacking order: works on every window manager
        win.present_with_time(_server_time(win))
        win.set_urgency_hint(False)
    except Exception:                                   # noqa: BLE001
        win.present()
    wm = shutil.which("wmctrl")                         # optional: ask like a taskbar does (also takes focus)
    if wm:
        def activate():
            try:
                xid = win.get_window().get_xid()
                subprocess.Popen([wm, "-i", "-a", hex(xid)], stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
            except Exception:                           # noqa: BLE001
                pass
            return False
        GLib.timeout_add(120, activate)
    if hold_ms:
        def release():
            try:
                win.set_keep_above(False)
            except Exception:                           # noqa: BLE001 - window already closed
                pass
            return False
        GLib.timeout_add(hold_ms, release)


def msg(parent, text, kind=Gtk.MessageType.INFO):
    d = Gtk.MessageDialog(transient_for=parent, modal=True, message_type=kind,
                          buttons=Gtk.ButtonsType.OK, text=text)
    d.set_position(Gtk.WindowPosition.CENTER)
    d.run()
    d.destroy()


def valid_url(u):
    p = urllib.parse.urlsplit(u.strip())
    return p.scheme in ("http", "https") and bool(p.netloc)


def status_text(d):
    if d.status == "Downloading":
        return f"{d.percent:.1f}%" if d.size > 0 else "Downloading"
    if d.status == "Paused":
        return f"{d.percent:.1f}% (stopped)" if d.percent > 0 else "Stopped"
    return d.status


# ------------------------------------------------------------ segment bar
class SegmentBar(Gtk.DrawingArea):
    """Shows which parts of the file each connection has fetched."""

    def __init__(self, d):
        super().__init__()
        self.d = d
        self.set_size_request(-1, 22)
        self.connect("draw", self.on_draw)

    def on_draw(self, _w, cr):
        w, h = self.get_allocated_width(), self.get_allocated_height()
        cr.set_source_rgb(0.93, 0.93, 0.93)
        cr.rectangle(0, 0, w, h)
        cr.fill()
        size, segs = self.d.size, list(self.d.segments)
        if size > 0:
            if self.d.status == "Complete":
                cr.set_source_rgb(0.18, 0.62, 0.35)
                cr.rectangle(0, 0, w, h)
                cr.fill()
            else:
                cr.set_source_rgb(0.18, 0.5, 0.85)
                for s in segs:
                    x0 = s.start / size * w
                    x1 = min(s.pos, s.end + 1) / size * w
                    if x1 > x0:
                        cr.rectangle(x0, 0, x1 - x0, h)
                        cr.fill()
                cr.set_source_rgba(0, 0, 0, 0.35)
                cr.set_line_width(1)
                for s in segs:
                    x = round(s.start / size * w) + 0.5
                    cr.move_to(x, 0)
                    cr.line_to(x, h)
                    cr.stroke()
        cr.set_source_rgba(0, 0, 0, 0.45)
        cr.set_line_width(1)
        cr.rectangle(0.5, 0.5, w - 1, h - 1)
        cr.stroke()
        return False


# --------------------------------------------------------- progress window
class ProgressWindow(Gtk.Window):
    def __init__(self, parent, manager, d):
        super().__init__(title=d.filename, transient_for=parent)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.manager, self.d, self._alive = manager, d, True
        self.set_default_size(520, -1)
        self.set_icon_name("ldm")
        self.set_border_width(12)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.add(box)

        url = Gtk.Label(label=d.url, xalign=0)
        url.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
        url.set_selectable(True)
        box.pack_start(url, False, False, 0)

        self.pbar = Gtk.ProgressBar()
        self.pbar.set_show_text(True)
        box.pack_start(self.pbar, False, False, 0)
        box.pack_start(SegmentBar(d), False, False, 0)
        self.bar = box.get_children()[-1]

        grid = Gtk.Grid(column_spacing=16, row_spacing=4)
        self.vals = {}
        for i, key in enumerate(["Status", "File size", "Downloaded", "Transfer rate",
                                 "Time left", "Resume capability", "Save to"]):
            grid.attach(Gtk.Label(label=key, xalign=0), 0, i, 1, 1)
            lbl = Gtk.Label(xalign=0)
            lbl.set_ellipsize(Pango.EllipsizeMode.MIDDLE)
            lbl.set_hexpand(True)
            grid.attach(lbl, 1, i, 1, 1)
            self.vals[key] = lbl
        box.pack_start(grid, False, False, 4)

        row = Gtk.Box(spacing=6)
        row.set_halign(Gtk.Align.END)
        self.b_pause = Gtk.Button(label="Pause")
        self.b_open = Gtk.Button(label="Open")
        self.b_folder = Gtk.Button(label="Open Folder")
        b_close = Gtk.Button(label="Close")
        for b in (self.b_pause, self.b_open, self.b_folder, b_close):
            row.pack_start(b, False, False, 0)
        box.pack_end(row, False, False, 0)
        self.b_pause.connect("clicked", self.on_pause)
        self.b_open.connect("clicked", self.on_open_file)
        self.b_folder.connect("clicked", self.on_open_folder)
        b_close.connect("clicked", lambda *_: self.destroy())
        self.connect("destroy", self.on_destroy)
        self.show_all()
        center_soon(self)
        self.update()
        GLib.timeout_add(300, self.update)

    def on_destroy(self, *_):
        self._alive = False

    def on_open_file(self, *_):
        path = self.d.path
        self.destroy()                       # like a normal application: close this window, then open
        open_path(path)

    def on_open_folder(self, *_):
        path = self.d.path
        self.destroy()
        reveal_file(path)

    def on_pause(self, *_):
        if self.d.status == "Downloading":
            self.manager.stop(self.d)
        else:
            self.manager.start(self.d)

    def update(self):
        if not self._alive:
            return False
        d = self.d
        done = d.status == "Complete"
        self.set_title(f"Complete - {d.filename}" if done else f"{d.percent:.0f}% {d.filename}")
        self.pbar.set_fraction(d.percent / 100.0)
        self.pbar.set_text(f"{d.percent:.1f}%" if d.size > 0 else d.status)
        self.bar.queue_draw()
        v = self.vals
        v["Status"].set_text(("Error: " + d.error) if d.status == "Error" else
                             "Download complete" if done else
                             "Receiving data..." if d.status == "Downloading" else
                             "Stopped" if d.status == "Paused" else d.status)
        v["File size"].set_text(core.fmt_size(d.size))
        v["Downloaded"].set_text(f"{core.fmt_size(d.downloaded)} ({d.percent:.2f}%)")
        v["Transfer rate"].set_text(core.fmt_rate(d.speed) or "-")
        v["Time left"].set_text(core.fmt_eta(d.eta) or "-")
        v["Resume capability"].set_text("Yes" if d.resumable else ("Unknown" if not d.probed else "No"))
        v["Save to"].set_text(d.path)
        self.b_pause.set_label("Pause" if d.status == "Downloading" else "Resume")
        self.b_pause.set_sensitive(not done)
        self.b_open.set_sensitive(done)
        self.b_folder.set_sensitive(done)
        return True


# ----------------------------------------------------------------- dialogs
class AddDialog(Gtk.Dialog):
    START, LATER = 1, 2

    def __init__(self, parent, settings, url="", video=False, quality=""):
        super().__init__(title="Enter new address to download", transient_for=parent, modal=True)
        self.set_position(Gtk.WindowPosition.CENTER)   # then centre_soon() fine-tunes it
        self.set_default_size(560, -1)
        self.add_button("Cancel", Gtk.ResponseType.CANCEL)
        self.add_button("Download Later", self.LATER)
        b = self.add_button("Start Download", self.START)
        b.get_style_context().add_class("suggested-action")
        self.set_default_response(self.START)
        grid = Gtk.Grid(column_spacing=10, row_spacing=8, margin=12)
        self.get_content_area().add(grid)

        self.url = Gtk.Entry(text=url, hexpand=True, activates_default=True)
        self.url.set_placeholder_text("https://")
        self.folder = Gtk.FileChooserButton(title="Save to",
                                            action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.folder.set_filename(settings["download_dir"])
        self.desc = Gtk.Entry(hexpand=True)
        self.conns = Gtk.SpinButton.new_with_range(1, 32, 1)
        self.conns.set_value(settings["connections"])
        for i, (label, w) in enumerate([("Address", self.url), ("Save to", self.folder),
                                        ("Description", self.desc), ("Connections", self.conns)]):
            grid.attach(Gtk.Label(label=label, xalign=0), 0, i, 1, 1)
            grid.attach(w, 1, i, 1, 1)
        self.video = Gtk.CheckButton(label="This is a video page (YouTube, Vimeo, ...) - "
                                           "download the video")
        self.video.set_active(video or core.is_video_page(url) or core.is_stream_url(url))
        self.quality = Gtk.ComboBoxText()
        for q in core.QUALITIES:
            self.quality.append_text(q)
        self.quality.set_active(0)
        if quality:
            if quality not in core.QUALITIES:
                self.quality.append_text(quality)
            self.quality.set_active(list(core.QUALITIES).index(quality)
                                    if quality in core.QUALITIES else len(core.QUALITIES))
        self.quality.set_sensitive(self.video.get_active())
        self.video.connect("toggled", lambda b: self.quality.set_sensitive(b.get_active()))
        self.url.connect("changed", lambda e: (core.is_video_page(e.get_text().strip())
                                               or core.is_stream_url(e.get_text().strip()))
                         and self.video.set_active(True))
        grid.attach(self.video, 0, 4, 2, 1)
        grid.attach(Gtk.Label(label="Quality", xalign=0), 0, 5, 1, 1)
        grid.attach(self.quality, 1, 5, 1, 1)
        self.show_all()
        center_soon(self)


class OptionsDialog(Gtk.Dialog):
    def __init__(self, parent, settings):
        super().__init__(title="Options", transient_for=parent, modal=True)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.s = settings
        self.add_button("Cancel", Gtk.ResponseType.CANCEL)
        self.add_button("OK", Gtk.ResponseType.OK)
        grid = Gtk.Grid(column_spacing=10, row_spacing=8, margin=12)
        self.get_content_area().add(grid)
        self.conns = Gtk.SpinButton.new_with_range(1, 32, 1)
        self.conns.set_value(settings["connections"])
        self.active = Gtk.SpinButton.new_with_range(1, 10, 1)
        self.active.set_value(settings["max_active"])
        self.folder = Gtk.FileChooserButton(title="Default download folder",
                                            action=Gtk.FileChooserAction.SELECT_FOLDER)
        self.folder.set_filename(settings["download_dir"])
        self.cat = Gtk.CheckButton(label="Sort downloads into category folders")
        self.cat.set_active(settings["categorize"])
        self.limit = Gtk.SpinButton.new_with_range(0, 1000000, 50)
        self.limit.set_value(settings["speed_limit_kb"])
        self.show_prog = Gtk.CheckButton(label="Show progress window when a download starts")
        self.show_prog.set_active(settings["show_progress"])
        self.keep = Gtk.CheckButton(label="Keep LDM running in the background when the window is closed")
        self.keep.set_active(settings["keep_running"])
        self.autostart = Gtk.CheckButton(label="Start LDM in the background when I log in")
        self.autostart.set_active(os.path.exists(AUTOSTART))
        self.capture = Gtk.CheckButton(label="Ask for confirmation before starting browser downloads")
        self.capture.set_active(settings["capture_dialog"])
        self.vcookies = Gtk.ComboBoxText()
        for i, b in enumerate(["(none)", "firefox", "chrome", "chromium", "brave", "edge", "vivaldi"]):
            self.vcookies.append_text(b)
            if b == (settings["video_cookies"] or "(none)"):
                self.vcookies.set_active(i)
        if self.vcookies.get_active() < 0:
            self.vcookies.set_active(0)
        rows = [("Default connections per download", self.conns),
                ("Maximum simultaneous queue downloads", self.active),
                ("Default download folder", self.folder),
                ("Speed limit per download (KB/s, 0 = unlimited)", self.limit),
                ("Use this browser's login cookies for video sites", self.vcookies)]
        for i, (label, w) in enumerate(rows):
            grid.attach(Gtk.Label(label=label, xalign=0), 0, i, 1, 1)
            grid.attach(w, 1, i, 1, 1)
        grid.attach(self.cat, 0, len(rows), 2, 1)
        grid.attach(self.show_prog, 0, len(rows) + 1, 2, 1)
        grid.attach(self.capture, 0, len(rows) + 2, 2, 1)
        grid.attach(self.keep, 0, len(rows) + 3, 2, 1)
        grid.attach(self.autostart, 0, len(rows) + 4, 2, 1)
        self.show_all()
        center_soon(self)

    def apply(self):
        s = self.s
        s["connections"] = int(self.conns.get_value())
        s["max_active"] = int(self.active.get_value())
        s["download_dir"] = self.folder.get_filename() or s["download_dir"]
        s["categorize"] = self.cat.get_active()
        s["speed_limit_kb"] = int(self.limit.get_value())
        s["show_progress"] = self.show_prog.get_active()
        s["capture_dialog"] = self.capture.get_active()
        s["keep_running"] = self.keep.get_active()
        set_autostart(self.autostart.get_active())
        v = self.vcookies.get_active_text()
        s["video_cookies"] = "" if v in (None, "(none)") else v
        try:
            s.save()
        except OSError:
            pass


# ------------------------------------------------------------- main window
COLS = ["id", "icon", "name", "size", "status", "eta", "rate", "last", "desc", "cat", "state", "pct"]


class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app, manager):
        super().__init__(application=app, title="Linux Download Manager")
        self.manager, self.settings = manager, manager.settings
        self.cat_key, self.rows, self.shown, self._busy = "all", {}, {}, False
        self.set_default_size(1000, 580)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_icon_name("ldm")

        css = Gtk.CssProvider()
        css.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(), css,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(root)
        root.pack_start(self.build_menu(), False, False, 0)
        root.pack_start(self.build_toolbar(), False, False, 0)

        self.paned = Gtk.Paned()
        self.paned.pack1(self.build_categories(), False, False)
        self.paned.pack2(self.build_list(), True, False)
        self.paned.set_position(190)
        root.pack_start(self.paned, True, True, 0)

        self.status = Gtk.Label(xalign=0)
        self.status.get_style_context().add_class("ldm-status")
        root.pack_end(self.status, False, False, 0)

        self.connect("delete-event", self.on_delete)
        self.tray = Tray(self)
        root.show_all()                      # the window itself is shown by present()
        self.tick()
        GLib.timeout_add(500, self.tick)

    # -- construction
    def build_menu(self):
        bar = Gtk.MenuBar()

        def menu(title, items):
            m = Gtk.Menu()
            for it in items:
                if it is None:
                    m.append(Gtk.SeparatorMenuItem())
                else:
                    mi = Gtk.MenuItem(label=it[0])
                    mi.connect("activate", lambda _w, cb=it[1]: cb())
                    m.append(mi)
            root = Gtk.MenuItem(label=title)
            root.set_submenu(m)
            bar.append(root)

        menu("Tasks", [("Add new download...", self.add_url),
                       ("Install / update video downloader...", self.act_install_video),
                       ("Browser integration...", self.act_integration), None,
                       ("Exit", self.quit_app)])
        menu("Downloads", [("Resume", self.act_resume), ("Stop", self.act_stop),
                           ("Stop all", self.act_stop_all), None,
                           ("Redownload", self.act_redownload), ("Delete", self.act_delete),
                           ("Delete all completed", self.act_delete_completed), None,
                           ("Start queue", self.manager.start_queue),
                           ("Stop queue", self.manager.stop_queue), None,
                           ("Options...", self.act_options)])
        menu("View", [("Show/hide categories", lambda: self.cats.set_visible(
            not self.cats.get_visible()))])
        menu("Help", [("About LDM", self.act_about)])
        return bar

    def build_toolbar(self):
        tb = Gtk.Toolbar()
        tb.set_style(Gtk.ToolbarStyle.BOTH)
        tb.set_icon_size(Gtk.IconSize.LARGE_TOOLBAR)
        items = [("Add URL", "list-add", self.add_url),
                 ("Resume", "media-playback-start", self.act_resume),
                 ("Stop", "media-playback-pause", self.act_stop),
                 ("Stop All", "media-playback-stop", self.act_stop_all),
                 None,
                 ("Delete", "edit-delete", self.act_delete),
                 ("Delete C.", "edit-clear-all", self.act_delete_completed),
                 None,
                 ("Options", "preferences-system", self.act_options),
                 ("Start Queue", "media-skip-forward", self.manager.start_queue),
                 ("Stop Queue", "process-stop", self.manager.stop_queue)]
        for it in items:
            if it is None:
                tb.insert(Gtk.SeparatorToolItem(), -1)
                continue
            btn = Gtk.ToolButton(label=it[0], icon_name=it[1])
            btn.connect("clicked", lambda _b, cb=it[2]: cb())
            btn.set_tooltip_text(it[0])
            tb.insert(btn, -1)
        return tb

    def build_categories(self):
        self.cat_store = Gtk.TreeStore(str, str, str)
        root = self.cat_store.append(None, ["All Downloads", "all", "folder-download"])
        for name in core.CATEGORY_NAMES:
            self.cat_store.append(root, [name, "cat:" + name, CAT_ICONS[name]])
        self.cat_store.append(None, ["Unfinished", "unfinished", "document-open-recent"])
        self.cat_store.append(None, ["Finished", "finished", "emblem-ok-symbolic"])
        q = self.cat_store.append(None, ["Queues", "queue", "view-list-symbolic"])
        self.cat_store.append(q, ["Main download queue", "queue", "view-list-symbolic"])
        view = Gtk.TreeView(model=self.cat_store, headers_visible=False)
        col = Gtk.TreeViewColumn("Categories")
        ir, tr = Gtk.CellRendererPixbuf(), Gtk.CellRendererText()
        col.pack_start(ir, False)
        col.pack_start(tr, True)
        col.add_attribute(ir, "icon-name", 2)
        col.add_attribute(tr, "text", 0)
        view.append_column(col)
        view.expand_all()
        view.get_selection().select_path(Gtk.TreePath.new_first())
        view.get_selection().connect("changed", self.on_category)
        sw = Gtk.ScrolledWindow(shadow_type=Gtk.ShadowType.IN)
        sw.add(view)
        sw.set_size_request(150, -1)
        self.cats = sw
        return sw

    def build_list(self):
        self.store = Gtk.ListStore(str, str, str, str, str, str, str, str, str, str, str, int)
        self.filter = self.store.filter_new()
        self.filter.set_visible_func(self.row_visible)
        self.tree = Gtk.TreeView(model=self.filter)
        self.tree.get_selection().set_mode(Gtk.SelectionMode.MULTIPLE)
        self.tree.set_rubber_banding(True)
        self.tree.set_grid_lines(Gtk.TreeViewGridLines.VERTICAL)

        def text_col(title, idx, width, align=0.0):
            r = Gtk.CellRendererText(xalign=align)
            c = Gtk.TreeViewColumn(title, r, text=idx)
            c.set_resizable(True)
            c.set_min_width(width)
            self.tree.append_column(c)
            return c

        name = Gtk.TreeViewColumn("File name")
        ir, tr = Gtk.CellRendererPixbuf(), Gtk.CellRendererText()
        tr.set_property("ellipsize", Pango.EllipsizeMode.END)
        name.pack_start(ir, False)
        name.pack_start(tr, True)
        name.add_attribute(ir, "icon-name", 1)
        name.add_attribute(tr, "text", 2)
        name.set_resizable(True)
        name.set_min_width(260)
        name.set_expand(True)
        self.tree.append_column(name)
        text_col("Size", 3, 80, 1.0)
        pr = Gtk.CellRendererProgress()
        pc = Gtk.TreeViewColumn("Status", pr, value=11, text=4)
        pc.set_resizable(True)
        pc.set_min_width(130)
        self.tree.append_column(pc)
        text_col("Time left", 5, 90)
        text_col("Transfer rate", 6, 100)
        text_col("Last try date", 7, 130)
        text_col("Description", 8, 120)

        self.tree.connect("row-activated", self.on_activated)
        self.tree.connect("button-press-event", self.on_click)
        sw = Gtk.ScrolledWindow(shadow_type=Gtk.ShadowType.IN)
        sw.add(self.tree)
        return sw

    # -- model plumbing
    def row_visible(self, model, it, _data):
        key = self.cat_key
        state, cat = model[it][10], model[it][9]
        if key == "all" or state is None:
            return True
        if key.startswith("cat:"):
            return cat == key[4:]
        if key == "unfinished":
            return state != "Complete"
        if key == "finished":
            return state == "Complete"
        if key == "queue":
            return state == "Queued"
        return True

    def on_category(self, sel):
        model, it = sel.get_selected()
        if it:
            self.cat_key = model[it][1]
            self.filter.refilter()

    def update_row(self, d):
        vals = [d.id, CAT_ICONS.get(d.category, "text-x-generic"), d.filename,
                core.fmt_size(d.size) if d.size >= 0 else "", status_text(d),
                core.fmt_eta(d.eta), core.fmt_rate(d.speed if d.status == "Downloading" else 0),
                core.fmt_time(d.last_try), d.description, d.category, d.status,
                int(d.percent)]
        if vals == self.shown.get(d.id):
            return
        self.shown[d.id] = vals
        ref = self.rows.get(d.id)
        if ref is None:
            it = self.store.append(vals)
            self.rows[d.id] = Gtk.TreeRowReference.new(self.store, self.store.get_path(it))
        else:
            self.store.set(self.store.get_iter(ref.get_path()), list(range(len(vals))), vals)

    def tick(self):
        self.manager.pump()
        self.process_inbox()
        seen = set()
        for d in self.manager.downloads:
            seen.add(d.id)
            self.update_row(d)
        for did in [i for i in self.rows if i not in seen]:
            ref = self.rows.pop(did)
            self.shown.pop(did, None)
            if ref.valid():
                self.store.remove(self.store.get_iter(ref.get_path()))
        active = [d for d in self.manager.downloads if d.status == "Downloading"]
        total = sum(d.speed for d in active)
        self.status.set_text(
            f"{len(self.manager.downloads)} downloads   |   {len(active)} active   |   "
            f"{core.fmt_rate(total) or '0 B/sec'}   |   "
            f"Queue: {'running' if self.manager.queue_running else 'stopped'}")
        return True

    def selected(self):
        model, paths = self.tree.get_selection().get_selected_rows()
        ids = {model[p][0] for p in paths}
        return [d for d in self.manager.downloads if d.id in ids]

    # -- actions
    def add_url(self, url="", referer="", cookie="", kind="", quality="", ua="", title=""):
        if not url:
            text = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).wait_for_text() or ""
            url = text.strip() if valid_url(text.strip()) else ""
        dlg = AddDialog(self, self.settings, url, video=(kind == "video"), quality=quality)
        bring_to_front(dlg)                  # stays above the browser until it is answered
        while True:
            resp = dlg.run()
            if resp not in (AddDialog.START, AddDialog.LATER):
                break
            link = dlg.url.get_text().strip()
            if not valid_url(link):
                msg(dlg, "Please enter a valid http:// or https:// address.", Gtk.MessageType.WARNING)
                continue
            video = dlg.video.get_active()
            if video and not self.ensure_video_tools():
                continue
            folder = dlg.folder.get_filename() or self.settings["download_dir"]
            custom = os.path.abspath(folder) != os.path.abspath(self.settings["download_dir"])
            d = self.manager.add(link, folder, None, dlg.desc.get_text(),
                                 int(dlg.conns.get_value()), categorize=(not custom and None), referer=referer, cookie=cookie, ua=ua, title=title,
                                 kind="ytdlp" if video else "http",
                                 quality=dlg.quality.get_active_text() if video else "",
                                 start=(resp == AddDialog.START))
            if custom:
                d.categorize = False
            self.tick()
            if resp == AddDialog.START and self.settings["show_progress"]:
                ProgressWindow(self, self.manager, d)
            break
        dlg.destroy()

    # -- browser captures
    def process_inbox(self):
        """Pick up links sent by the browser extension (via the native host)."""
        if self._busy:
            return
        try:
            names = sorted(n for n in os.listdir(core.INBOX_DIR) if n.endswith(".json"))
        except OSError:
            return
        for name in names:
            path = os.path.join(core.INBOX_DIR, name)
            try:
                with open(path) as f:
                    data = json.load(f)
            except (OSError, ValueError):
                data = None
            try:
                os.remove(path)
            except OSError:
                pass
            if not isinstance(data, dict) or not valid_url(str(data.get("url", ""))):
                continue
            self._busy = True
            bring_to_front(self)             # the app window comes forward together with its prompt
            try:
                self.capture(str(data["url"]), str(data.get("referer", "")),
                             str(data.get("cookie", "")), str(data.get("kind", "")),
                             str(data.get("quality", "")), str(data.get("ua", "")),
                             str(data.get("title", "")))
            finally:
                self._busy = False
                self.set_keep_above(False)

    def capture(self, url, referer, cookie, kind="", quality="", ua="", title=""):
        if kind == "video" and quality and not self.settings["capture_dialog"]:
            if self.ensure_video_tools():              # quality picked on the page: start at once
                d = self.manager.add(url, kind="ytdlp", quality=quality, cookie=cookie,
                                     referer=referer, ua=ua, title=title)
                self.tick()
                if self.settings["show_progress"]:
                    bring_to_front(ProgressWindow(self, self.manager, d), hold_ms=4000)
            return
        if self.settings["capture_dialog"] or kind == "video":
            self.add_url(url, referer, cookie, kind, quality, ua, title)
            return
        d = self.manager.add(url, referer=referer, cookie=cookie, ua=ua, title=title)
        self.tick()
        if self.settings["show_progress"]:
            bring_to_front(ProgressWindow(self, self.manager, d), hold_ms=4000)

    # -- video downloader (yt-dlp) management
    def run_install(self):
        dlg = Gtk.Dialog(title="Video downloader", transient_for=self, modal=True)
        dlg.set_position(Gtk.WindowPosition.CENTER)
        dlg.set_default_size(380, -1)
        box = dlg.get_content_area()
        box.set_border_width(16)
        box.set_spacing(10)
        label = Gtk.Label(label="Starting...", xalign=0)
        spin = Gtk.Spinner()
        spin.start()
        box.pack_start(label, False, False, 0)
        box.pack_start(spin, False, False, 0)
        state = {"log": "Starting...", "err": None, "done": False}

        def work():
            try:
                core.install_video_tools(lambda m: state.__setitem__("log", m))
            except Exception as e:                      # noqa: BLE001
                state["err"] = str(e) or repr(e)
            state["done"] = True

        def poll():
            label.set_text(state["log"])
            if state["done"]:
                dlg.response(Gtk.ResponseType.OK)
                return False
            return True

        threading.Thread(target=work, daemon=True).start()
        GLib.timeout_add(200, poll)
        dlg.show_all()
        dlg.run()
        dlg.destroy()
        if state["err"]:
            msg(self, "Could not install the video downloader:\n" + state["err"],
                Gtk.MessageType.ERROR)
            return False
        return True

    def ensure_video_tools(self):
        """Make sure yt-dlp and a JavaScript runtime exist; offer to install them."""
        missing = [p for p in core.video_tools_status() if not p.startswith("ffmpeg")]
        if missing:
            dlg = Gtk.MessageDialog(
                transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO, text="Video downloads need extra components",
                secondary_text="Missing: " + ", ".join(missing) + ".\n\nDownload them now from "
                "their official GitHub releases (about 100 MB, checksum-verified)?")
            ok = dlg.run() == Gtk.ResponseType.YES
            dlg.destroy()
            if not ok or not self.run_install():
                return False
        if not core.find_tool("ffmpeg") and not getattr(self, "_warned_ffmpeg", False):
            self._warned_ffmpeg = True
            msg(self, "ffmpeg is not installed, so HD videos (separate video and audio streams) "
                      "cannot be merged.\nInstall it with:  sudo apt install ffmpeg",
                Gtk.MessageType.WARNING)
        return core.find_ytdlp() is not None

    def act_install_video(self):
        if self.run_install():
            msg(self, "Video downloader is up to date.")

    def act_integration(self):
        dlg = Gtk.Dialog(title="Browser integration", transient_for=self, modal=True)
        dlg.set_position(Gtk.WindowPosition.CENTER)
        dlg.add_button("Close", Gtk.ResponseType.CLOSE)
        box = dlg.get_content_area()
        box.set_spacing(10)
        box.set_border_width(14)
        text = Gtk.Label(xalign=0, wrap=True, max_width_chars=72, selectable=True)
        text.set_markup(
            "<b>1.</b> Keep LDM running (it stays in the background when you close the window). "
            "The extension talks to it over a private local link, which works in every browser. "
            "<i>Register for my browsers</i> is only an optional extra that lets the browser "
            "start LDM by itself.\n\n"
            "<b>2. Chrome / Chromium / Brave / Edge:</b> open <tt>chrome://extensions</tt>, "
            "turn on Developer mode, choose <i>Load unpacked</i> and select the "
            "<tt>chrome</tt> folder (button below).\n\n"
            "<b>3. Firefox:</b> open <tt>about:debugging#/runtime/this-firefox</tt>, choose "
            "<i>Load Temporary Add-on</i> and select <tt>firefox/manifest.json</tt>. A permanent "
            "Firefox install needs the add-on to be signed by Mozilla.\n\n"
            "Then click any download in your browser, or right-click a link and choose "
            "<i>Download with LDM</i>.")
        box.pack_start(text, False, False, 0)
        row = Gtk.Box(spacing=8)
        b_reg = Gtk.Button(label="Register for my browsers")
        b_dir = Gtk.Button(label="Open extension folder")
        b_diag = Gtk.Button(label="Check setup")
        row.pack_start(b_reg, False, False, 0)
        row.pack_start(b_dir, False, False, 0)
        row.pack_start(b_diag, False, False, 0)
        box.pack_start(row, False, False, 0)
        result = Gtk.Label(xalign=0, wrap=True)
        box.pack_start(result, False, False, 0)

        def register(_b):
            try:
                out = subprocess.run([HOST, "--install-user"], capture_output=True,
                                     text=True, timeout=20)
                result.set_text((out.stdout or out.stderr or "Done.").strip())
            except (OSError, subprocess.SubprocessError) as e:
                result.set_text(f"Could not register: {e}")

        def diagnose(_b):
            port = getattr(self.get_application(), "port", None)
            link = (f"Local link to the browser: listening on 127.0.0.1:{port}" if port else
                    "Local link to the browser: NOT listening (ports 38477-38481 busy?)")
            try:
                out = subprocess.run([HOST, "--diagnose"], capture_output=True, text=True, timeout=20)
                result.set_text(link + "\n" + (out.stdout or out.stderr).strip())
            except (OSError, subprocess.SubprocessError) as e:
                result.set_text(f"Could not run the check: {e}")
            result.set_selectable(True)

        b_diag.connect("clicked", diagnose)
        b_reg.connect("clicked", register)
        b_dir.connect("clicked", lambda *_: open_path(EXT_DIR))
        dlg.show_all()
        dlg.run()
        dlg.destroy()

    def act_resume(self):
        for d in self.selected():
            self.manager.start(d)

    def act_stop(self):
        for d in self.selected():
            self.manager.stop(d)

    def act_stop_all(self):
        self.manager.stop_all()

    def act_redownload(self):
        for d in self.selected():
            self.manager.redownload(d)

    def confirm_delete(self, count):
        dlg = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                                buttons=Gtk.ButtonsType.YES_NO,
                                text=f"Remove {count} download(s) from the list?")
        chk = Gtk.CheckButton(label="Also delete the file(s) from disk")
        chk.show()
        dlg.get_message_area().pack_start(chk, False, False, 0)
        ok = dlg.run() == Gtk.ResponseType.YES
        files = chk.get_active()
        dlg.destroy()
        return ok, files

    def act_delete(self):
        sel = self.selected()
        if not sel:
            return
        ok, files = self.confirm_delete(len(sel))
        if ok:
            for d in sel:
                self.manager.remove(d, files)
            self.tick()

    def act_delete_completed(self):
        done = [d for d in self.manager.downloads if d.status == "Complete"]
        if not done:
            return
        ok, files = self.confirm_delete(len(done))
        if ok:
            for d in done:
                self.manager.remove(d, files)
            self.tick()

    def act_options(self):
        dlg = OptionsDialog(self, self.settings)
        if dlg.run() == Gtk.ResponseType.OK:
            dlg.apply()
        dlg.destroy()

    def act_about(self):
        a = Gtk.AboutDialog(transient_for=self, modal=True)
        a.set_program_name("Linux Download Manager (LDM)")
        a.set_version(__version__)
        a.set_comments("A multi-connection download accelerator for Linux.\n"
                       "Dynamic segmentation, pause/resume and queues.")
        a.set_logo_icon_name("ldm")
        a.set_copyright("Copyright \u00a9 2026 SL_Linux")
        a.set_authors(["SL_Linux"])
        a.set_artists(["SL_Linux"])
        a.set_license_type(Gtk.License.GPL_3_0)
        a.run()
        a.destroy()

    def on_activated(self, _tree, path, _col):
        did = self.filter[path][0]
        d = next((x for x in self.manager.downloads if x.id == did), None)
        if d is None:
            return
        if d.status == "Complete":
            open_path(d.path)
        else:
            ProgressWindow(self, self.manager, d)

    def on_click(self, tree, ev):
        if ev.button != 3:
            return False
        hit = tree.get_path_at_pos(int(ev.x), int(ev.y))
        if hit and not tree.get_selection().path_is_selected(hit[0]):
            tree.get_selection().unselect_all()
            tree.get_selection().select_path(hit[0])
        sel = self.selected()
        m = Gtk.Menu()
        entries = [("Open", lambda: [open_path(d.path) for d in sel if d.status == "Complete"]),
                   ("Open folder", lambda: [reveal_file(d.path) for d in sel]),
                   None,
                   ("Resume", self.act_resume), ("Stop", self.act_stop),
                   ("Redownload", self.act_redownload), None,
                   ("Copy address", lambda: Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
                    .set_text("\n".join(d.url for d in sel), -1)),
                   ("Delete", self.act_delete)]
        for e in entries:
            if e is None:
                m.append(Gtk.SeparatorMenuItem())
                continue
            mi = Gtk.MenuItem(label=e[0])
            mi.set_sensitive(bool(sel))
            mi.connect("activate", lambda _w, cb=e[1]: cb())
            m.append(mi)
        m.show_all()
        m.popup_at_pointer(ev)
        return True

    def confirm_exit(self):
        if any(d.status == "Downloading" for d in self.manager.downloads):
            dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                    message_type=Gtk.MessageType.QUESTION,
                                    buttons=Gtk.ButtonsType.YES_NO,
                                    text="Downloads are in progress. Stop them and exit?",
                                    secondary_text="Progress is saved; you can resume later.")
            ok = dlg.run() == Gtk.ResponseType.YES
            dlg.destroy()
            return ok
        return True

    def quit_app(self):
        if self.confirm_exit():
            self.get_application().quit()

    def notify_background(self):
        """Tell the user LDM is still running (matters where there is no tray, e.g. stock GNOME)."""
        if getattr(self, "_told_background", False):
            return
        self._told_background = True
        try:
            n = Gio.Notification.new("LDM is still running")
            n.set_body("Downloads continue in the background. Open LDM from your applications "
                       "menu to show the window again, or choose Tasks > Exit to quit.")
            n.set_icon(Gio.ThemedIcon.new("ldm"))
            self.get_application().send_notification("ldm-background", n)
        except Exception:                               # noqa: BLE001 - cosmetic
            pass

    def on_delete(self, *_):
        if self.settings["keep_running"]:      # keep downloading / listening to the browser
            self.hide()
            self.notify_background()
            return True
        self.quit_app()
        return True
