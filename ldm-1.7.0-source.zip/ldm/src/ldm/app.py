# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
"""LDM application entry point (single-instance Gtk.Application)."""
import os
import sys

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gio, GLib, Gtk  # noqa: E402

from . import core  # noqa: E402
from .gui import MainWindow, bring_to_front, valid_url  # noqa: E402
from .server import start_server  # noqa: E402


class App(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="org.ldm.LinuxDownloadManager",
                         flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        GLib.set_application_name("Linux Download Manager")
        self.win = None
        self.manager = None
        self.server, self.port = None, None
        self.add_main_option("capture", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Handle links sent by the browser extension", None)
        self.add_main_option("background", 0, GLib.OptionFlags.NONE, GLib.OptionArg.NONE,
                             "Start without showing the window", None)

    def do_startup(self):
        Gtk.Application.do_startup(self)
        os.makedirs(core.INBOX_DIR, mode=0o700, exist_ok=True)
        self.manager = core.Manager(core.Settings())
        self.server, self.port = start_server()     # lets the browser extension reach us
        self.hold()                                 # stay alive when the window is hidden

    def ensure_window(self):
        if self.win is None:
            self.win = MainWindow(self, self.manager)
        return self.win

    def do_activate(self):
        self.ensure_window().present()

    def do_command_line(self, cl):
        opts = cl.get_options_dict()
        args = [a for a in cl.get_arguments()[1:] if not a.startswith("-")]
        win = self.ensure_window()
        links = [core.parse_ldm_link(a) for a in args if a.startswith("ldm://")]
        urls = [a for a in args if not a.startswith("ldm://") and valid_url(a)]
        silent = opts.contains("background") or opts.contains("capture")
        if links or urls or not silent:
            bring_to_front(win, hold_ms=3000)   # plain launch, ldm:// link or URL: show the window
        for link in links:                          # always shows the Add dialog (never silent)
            if link and link["action"] == "add" and core.valid_http_url(link["url"]):
                win.add_url(link["url"], link["referer"], "", link["kind"], link["quality"])
        for url in urls:
            win.add_url(url)
        win.process_inbox()
        return 0

    def do_shutdown(self):
        if self.server:
            self.server.shutdown()
        if self.manager:
            self.manager.shutdown()
        Gtk.Application.do_shutdown(self)


def main(argv):
    return App().run(argv)
