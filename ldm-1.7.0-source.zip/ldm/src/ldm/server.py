# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
"""Local link between the browser extension and LDM (127.0.0.1 only).

Works in every browser, including sandboxed ones where native messaging is unavailable.
Only requests from the LDM extension (or without a browser Origin) are accepted, so an
ordinary web page cannot add downloads.
"""
import http.server
import json
import threading

from . import __version__, core

PORTS = range(38477, 38482)
LOCAL_HOSTS = {"127.0.0.1", "localhost"}


class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "LDM"

    def log_message(self, *_):
        pass

    def origin_ok(self):
        o = self.headers.get("Origin", "")
        return o.startswith("moz-extension://") or o == f"chrome-extension://{core.CHROME_EXT_ID}"

    def host_ok(self):                         # defeats DNS-rebinding tricks
        return self.headers.get("Host", "").rsplit(":", 1)[0] in LOCAL_HOSTS

    def reply(self, code, obj=None):
        body = json.dumps(obj).encode() if obj is not None else b""
        self.send_response(code)
        if self.origin_ok():
            self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin"))
            self.send_header("Vary", "Origin")
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        if not (self.host_ok() and self.origin_ok()):
            return self.reply(403, {"ok": False})
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", self.headers.get("Origin"))
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Max-Age", "600")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        if self.host_ok() and self.path == "/ping":
            return self.reply(200, {"ok": True, "version": __version__})
        self.reply(404, {"ok": False})

    def do_POST(self):
        origin = self.headers.get("Origin", "")
        if not self.host_ok() or (origin and not self.origin_ok()):
            return self.reply(403, {"ok": False, "error": "forbidden"})
        if "application/json" not in self.headers.get("Content-Type", ""):
            return self.reply(415, {"ok": False, "error": "JSON required"})
        n = int(self.headers.get("Content-Length") or 0)
        if n > 65536:
            return self.reply(413, {"ok": False, "error": "too large"})
        try:
            msg = json.loads(self.rfile.read(n) or b"{}")
        except ValueError:
            return self.reply(400, {"ok": False, "error": "bad json"})
        if self.path == "/add":
            ok = core.write_inbox(msg)
            return self.reply(200 if ok else 400, {"ok": ok} if ok else {"ok": False, "error": "unsupported URL"})
        if self.path == "/formats":
            url = str(msg.get("url", ""))
            if not core.valid_http_url(url):
                return self.reply(400, {"ok": False, "error": "unsupported URL"})
            return self.reply(200, core.list_formats(url, msg.get("referer", ""), msg.get("ua", "")))
        self.reply(404, {"ok": False})


def start_server():
    """Start on the first free port; returns (server, port) or (None, None)."""
    for port in PORTS:
        try:
            srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), Handler)
        except OSError:
            continue
        srv.daemon_threads = True
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return srv, port
    return None, None
