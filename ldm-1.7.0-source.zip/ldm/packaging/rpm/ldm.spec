# Copyright (C) 2026 SL_Linux - GPL-3.0-or-later
%{!?ldm_version: %global ldm_version 1.7.0}
Name:           ldm
Version:        %{ldm_version}
Release:        1%{?dist}
Summary:        Linux Download Manager - multi-connection download accelerator
License:        GPL-3.0-or-later
BuildArch:      noarch
Source0:        ldm-%{version}.tar.gz
Requires:       python3 >= 3.8
Requires:       xdg-utils
%if 0%{?suse_version}
Requires:       python3-gobject
Requires:       python3-gobject-Gdk
Requires:       python3-cairo
Requires:       typelib-1_0-Gtk-3_0
%else
Requires:       python3-gobject
Requires:       python3-cairo
Requires:       gtk3
%endif
Recommends:     ffmpeg
Recommends:     wmctrl
Recommends:     desktop-file-utils

%description
LDM splits files into dynamic segments fetched over several simultaneous
connections, with pause/resume, queues, automatic category folders, speed
limiting, video downloading (yt-dlp) and browser integration for Firefox and
Chromium-based browsers. Copyright (C) 2026 SL_Linux.

%prep
%setup -q

%build
# nothing to build (pure Python)

%install
%if "%{_lib}" == "lib64"
./install.sh --system --prefix %{_prefix} --destdir %{buildroot} --no-hooks --lib64
%else
./install.sh --system --prefix %{_prefix} --destdir %{buildroot} --no-hooks
%endif

# RPM installs docs/license through %doc and %license
rm -rf %{buildroot}%{_datadir}/doc/ldm

%post
update-desktop-database -q %{_datadir}/applications >/dev/null 2>&1 || :
gtk-update-icon-cache -q -t -f %{_datadir}/icons/hicolor >/dev/null 2>&1 || :

%postun
update-desktop-database -q %{_datadir}/applications >/dev/null 2>&1 || :
gtk-update-icon-cache -q -t -f %{_datadir}/icons/hicolor >/dev/null 2>&1 || :

%files
%license LICENSE
%doc README.md
%{_bindir}/ldm
%{_prefix}/lib/ldm
%{_datadir}/ldm
%{_datadir}/applications/org.ldm.LinuxDownloadManager.desktop
%{_datadir}/icons/hicolor/*/apps/ldm.*
%{_prefix}/lib/mozilla/native-messaging-hosts/org.ldm.host.json
%if "%{_lib}" == "lib64"
%{_prefix}/lib64/mozilla/native-messaging-hosts/org.ldm.host.json
%endif
%config(noreplace) /etc/opt/chrome/native-messaging-hosts/org.ldm.host.json
%config(noreplace) /etc/chromium/native-messaging-hosts/org.ldm.host.json
%config(noreplace) /etc/opt/edge/native-messaging-hosts/org.ldm.host.json

%changelog
* Fri Oct 16 2026 SL_Linux <noreply@sl-linux.invalid> - 1.7.0-1
- Distro-neutral layout, new icon, SL_Linux credits.
