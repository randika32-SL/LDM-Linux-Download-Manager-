# LDM logo guidelines

Copyright (C) 2026 SL_Linux

![Logo guidelines](logo-guidelines.png)

The LDM icon is a rounded badge with a downward arrow whose shaft is cut into
segments (a file arriving in parts) above a progress bar. Two artwork versions exist
in [`logo/`](../logo): the **full icon** (`ldm.svg`) and the **compact icon**
(`ldm-compact.svg`, no segment gaps) for very small sizes. PNG exports are in
`logo/png/`.

## 1. Clear space

Keep a clear space of **X** around the icon on all four sides, where **X is one
quarter of the icon's width** (the badge, not the transparent canvas around it).
No text, window edges, other logos or busy imagery may enter that zone.

## 2. Minimum size

| Version | Minimum on screen | Minimum in print |
| --- | --- | --- |
| Full icon (`ldm.svg`, `ldm-32.png` and larger) | **32 px** | **10 mm** |
| Compact icon (`ldm-compact.svg`, `ldm-16/22/24.png`) | **16 px** | **5 mm** |

* Below 32 px always switch to the compact icon.
* Never use the icon below 16 px.

## 3. Usage rules

**Do**

* Use the supplied SVG/PNG files unchanged and scale them proportionally.
* Keep the clear space free.
* Place the icon on solid, calm backgrounds (white, light, dark and the brand teal all work).

**Do not**

* Recolor the icon or add outlines, shadows or other effects.
* Stretch, rotate, skew or crop the badge.
* Redraw or rearrange the arrow segments.

## Colors

| Role | Value |
| --- | --- |
| Gradient start (top-left) | `#5B5BF0` |
| Gradient end (bottom-right) | `#14B8D4` |
| Arrow | `#FFFFFF` |
| Progress accent | `#9CF5D0` |
