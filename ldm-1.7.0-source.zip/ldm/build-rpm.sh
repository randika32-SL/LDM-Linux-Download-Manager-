#!/bin/sh
# Copyright (C) 2026 SL_Linux - GPL-3.0-or-later
# Builds ldm-<version>-1.noarch.rpm for Fedora, RHEL/Rocky/Alma, openSUSE, ... (needs rpmbuild)
set -eu
SRC=$(cd "$(dirname "$0")" && pwd); VER=$(cat "$SRC/VERSION"); OUT=${1:-$SRC}
TOP=$(mktemp -d); trap 'rm -rf "$TOP"' EXIT
mkdir -p "$TOP/SOURCES" "$TOP/BUILD" "$TOP/RPMS" "$TOP/SRPMS" "$TOP/SPECS"
tar -C "$SRC" --exclude='./.git' --exclude='*.deb' --exclude='*.rpm' --exclude='__pycache__' \
    --transform "s,^\./,ldm-$VER/," -czf "$TOP/SOURCES/ldm-$VER.tar.gz" .
rpmbuild -bb "$SRC/packaging/rpm/ldm.spec" --define "_topdir $TOP" --define "ldm_version $VER"
cp "$TOP"/RPMS/noarch/*.rpm "$OUT/"
