#!/bin/sh
# Copyright (C) 2026 SL_Linux
# SPDX-License-Identifier: GPL-3.0-or-later
#
# LDM installer - works on any Linux distribution.
#   ./install.sh                  per-user install into ~/.local (no root needed)
#   sudo ./install.sh             system-wide install into /usr/local
#   ./install.sh --deps           also install the required system packages
# Packagers: ./install.sh --system --prefix /usr --destdir "$pkgdir" --no-hooks
set -eu

SRC=$(cd "$(dirname "$0")" && pwd)
VERSION=$(cat "$SRC/VERSION" 2>/dev/null || echo "?")
MODE=""; PREFIX=""; DESTDIR="${DESTDIR:-}"; HOOKS=1; DEPS=0; DRY=0; UNINSTALL=0; LIB64=""

usage() {
cat <<USAGE
LDM $VERSION installer

Usage: ./install.sh [options]
  --user            install for the current user only (default when not root)
  --system          install system-wide (default when root)
  --prefix DIR      install prefix (default: ~/.local for --user, /usr/local for --system)
  --deps            install the required system packages first (uses sudo)
  --deps-only       only install the required system packages
  --dry-run         with --deps/--deps-only: print the command instead of running it
  --uninstall       remove LDM (use the same --user/--system/--prefix as when installing)
  --destdir DIR     staging root for packagers
  --no-hooks        do not refresh icon / desktop caches (packagers)
  --lib64           also register Firefox's native-messaging host under /usr/lib64
  -h, --help        show this help
USAGE
}

while [ $# -gt 0 ]; do
  case "$1" in
    --user) MODE=user ;;
    --system) MODE=system ;;
    --prefix) PREFIX=$2; shift ;;
    --destdir) DESTDIR=$2; shift ;;
    --no-hooks) HOOKS=0 ;;
    --deps) DEPS=1 ;;
    --deps-only) DEPS=2 ;;
    --dry-run) DRY=1 ;;
    --uninstall) UNINSTALL=1 ;;
    --lib64) LIB64=1 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "unknown option: $1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

if [ -z "$MODE" ]; then if [ "$(id -u)" = 0 ]; then MODE=system; else MODE=user; fi; fi
if [ -z "$PREFIX" ]; then if [ "$MODE" = user ]; then PREFIX="$HOME/.local"; else PREFIX=/usr/local; fi; fi
D="$DESTDIR$PREFIX"

# ---------------------------------------------------------------- dependencies
detect_pm() {
  f=${OS_RELEASE_FILE:-/etc/os-release}; ids=""
  if [ -r "$f" ]; then ids=$( . "$f" >/dev/null 2>&1; echo "${ID:-} ${ID_LIKE:-}" ); fi
  for id in $ids; do
    case "$id" in
      debian|ubuntu|linuxmint|pop|elementary|zorin|raspbian|kali|neon|devuan|mx) echo apt; return ;;
      fedora|rhel|centos|rocky|almalinux|ol|nobara|amzn) echo dnf; return ;;
      opensuse*|suse|sles|sled) echo zypper; return ;;
      arch|manjaro|endeavouros|garuda|cachyos|artix) echo pacman; return ;;
      alpine|postmarketos) echo apk; return ;;
      void) echo xbps; return ;;
      gentoo) echo emerge; return ;;
      nixos) echo nix; return ;;
    esac
  done
  for pair in apt-get:apt dnf:dnf zypper:zypper pacman:pacman apk:apk xbps-install:xbps emerge:emerge; do
    if command -v "${pair%%:*}" >/dev/null 2>&1; then echo "${pair##*:}"; return; fi
  done
  echo unknown
}

deps_command() {
  S=""; if [ "$(id -u)" != 0 ]; then S="sudo "; fi
  case "$1" in
    apt)    echo "${S}apt-get install -y python3 python3-gi python3-gi-cairo gir1.2-gtk-3.0 gir1.2-gdkpixbuf-2.0 xdg-utils ffmpeg" ;;
    dnf)    echo "${S}dnf install -y python3 python3-gobject python3-cairo gtk3 xdg-utils" ;;
    zypper) echo "${S}zypper install -y python3 python3-gobject python3-gobject-Gdk python3-cairo typelib-1_0-Gtk-3_0 xdg-utils ffmpeg" ;;
    pacman) echo "${S}pacman -S --needed --noconfirm python python-gobject python-cairo gtk3 xdg-utils ffmpeg" ;;
    apk)    echo "${S}apk add python3 py3-gobject3 py3-cairo gtk+3.0 xdg-utils ffmpeg" ;;
    xbps)   echo "${S}xbps-install -y python3 python3-gobject python3-cairo gtk+3 xdg-utils ffmpeg" ;;
    emerge) echo "${S}emerge --noreplace dev-lang/python dev-python/pygobject dev-python/pycairo x11-libs/gtk+:3 x11-misc/xdg-utils media-video/ffmpeg" ;;
    nix)    echo "# NixOS: add python3, python3Packages.pygobject3, gtk3, gobject-introspection, xdg-utils and ffmpeg to your configuration" ;;
    *)      echo "# Unknown distribution: install Python 3.8+, PyGObject (GTK 3 bindings), pycairo, xdg-utils and ffmpeg" ;;
  esac
}

if [ "$DEPS" -gt 0 ]; then
  PM=$(detect_pm); CMD=$(deps_command "$PM")
  echo "Package manager: $PM"
  if [ "$PM" = dnf ]; then echo "Note: for video merging install ffmpeg too (Fedora: ffmpeg-free, or ffmpeg from RPM Fusion)."; fi
  if [ "$DRY" = 1 ]; then echo "$CMD"; else echo "+ $CMD"; case "$CMD" in "#"*) ;; *) sh -c "$CMD" ;; esac; fi
  if [ "$DEPS" = 2 ]; then exit 0; fi
fi

# ------------------------------------------------------------------- uninstall
manifest_dirs() {
  echo /usr/lib/mozilla/native-messaging-hosts
  if [ -n "$LIB64" ] || { [ -z "$DESTDIR" ] && [ -d /usr/lib64 ]; }; then echo /usr/lib64/mozilla/native-messaging-hosts; fi
  echo /etc/opt/chrome/native-messaging-hosts
  echo /etc/chromium/native-messaging-hosts
  echo /etc/opt/edge/native-messaging-hosts
}

if [ "$UNINSTALL" = 1 ]; then
  if [ "$MODE" = user ] && [ -x "$D/lib/ldm/ldm-native-host" ]; then "$D/lib/ldm/ldm-native-host" --uninstall-user || true; fi
  rm -rf "$D/share/ldm" "$D/lib/ldm" "$D/share/doc/ldm"
  rm -f "$D/bin/ldm" "$D/share/applications/org.ldm.LinuxDownloadManager.desktop" "$D/share/icons/hicolor/scalable/apps/ldm.svg"
  for s in 16 22 24 32 48 64 96 128 256 512; do rm -f "$D/share/icons/hicolor/${s}x${s}/apps/ldm.png"; done
  if [ "$MODE" = system ]; then for m in $(manifest_dirs); do rm -f "$DESTDIR$m/org.ldm.host.json"; done; fi
  if [ "$HOOKS" = 1 ] && [ -z "$DESTDIR" ]; then
    command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q "$D/share/applications" || true
    command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t -f "$D/share/icons/hicolor" || true
  fi
  echo "LDM removed from $D (your downloads and settings in ~/.config/ldm and ~/.local/share/ldm were left alone)."
  exit 0
fi

# --------------------------------------------------------------------- install
if [ -z "$DESTDIR" ]; then
  python3 - <<'PY' || echo "WARNING: Python 3.8+ with PyGObject/GTK 3 was not found. Run: ./install.sh --deps-only" >&2
import sys
assert sys.version_info >= (3, 8), "Python 3.8 or newer is required"
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk  # noqa: F401
PY
fi

install -d "$D/bin" "$D/lib/ldm" "$D/share/ldm/lib/ldm" "$D/share/ldm/extension" \
  "$D/share/applications" "$D/share/doc/ldm" "$D/share/icons/hicolor/scalable/apps"
install -m 755 "$SRC/bin/ldm" "$D/bin/ldm"
install -m 755 "$SRC/libexec/ldm-native-host" "$D/lib/ldm/ldm-native-host"
install -m 644 "$SRC"/src/ldm/*.py "$D/share/ldm/lib/ldm/"
for b in chrome firefox; do
  rm -rf "$D/share/ldm/extension/$b"
  cp -r "$SRC/extension/$b" "$D/share/ldm/extension/$b"
done
find "$D/share/ldm/extension" -type d -exec chmod 755 {} +
find "$D/share/ldm/extension" -type f -exec chmod 644 {} +

DESK="$D/share/applications/org.ldm.LinuxDownloadManager.desktop"
if [ "$MODE" = user ]; then sed "s|^Exec=ldm |Exec=$PREFIX/bin/ldm |" "$SRC/data/org.ldm.LinuxDownloadManager.desktop" > "$DESK"
else cp "$SRC/data/org.ldm.LinuxDownloadManager.desktop" "$DESK"; fi
chmod 644 "$DESK"

install -m 644 "$SRC/data/icons/ldm.svg" "$D/share/icons/hicolor/scalable/apps/ldm.svg"
for s in 16 22 24 32 48 64 96 128 256 512; do
  install -d "$D/share/icons/hicolor/${s}x${s}/apps"
  install -m 644 "$SRC/data/icons/ldm-$s.png" "$D/share/icons/hicolor/${s}x${s}/apps/ldm.png"
done
install -m 644 "$SRC/LICENSE" "$D/share/doc/ldm/LICENSE"
install -m 644 "$SRC/README.md" "$D/share/doc/ldm/README.md"

# Browser registration: system-wide manifests, or per-user ones for a user install.
if [ "$MODE" = system ]; then
  HOSTP="$PREFIX/lib/ldm/ldm-native-host"
  for m in $(manifest_dirs); do
    install -d "$DESTDIR$m"
    case "$m" in */mozilla/*) KIND=firefox ;; *) KIND=chrome ;; esac
    python3 "$SRC/libexec/ldm-native-host" --print-manifest "$KIND" --host-path "$HOSTP" > "$DESTDIR$m/org.ldm.host.json"
    chmod 644 "$DESTDIR$m/org.ldm.host.json"
  done
elif [ -z "$DESTDIR" ]; then
  "$D/lib/ldm/ldm-native-host" --install-user || true
fi

if [ "$HOOKS" = 1 ] && [ -z "$DESTDIR" ]; then
  python3 -m compileall -q "$D/share/ldm/lib" >/dev/null 2>&1 || true
  command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database -q "$D/share/applications" || true
  command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q -t -f "$D/share/icons/hicolor" || true
fi

echo "LDM $VERSION installed to $D"
if [ "$MODE" = user ]; then
  case ":$PATH:" in *":$PREFIX/bin:"*) ;; *) echo "Note: add $PREFIX/bin to your PATH to run 'ldm' from a terminal (the menu entry works already)." ;; esac
fi
echo "Next: load the browser extension - see INSTALL.md, section 'Browser extension'."
