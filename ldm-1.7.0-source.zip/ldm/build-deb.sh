#!/bin/sh
# Copyright (C) 2026 SL_Linux - GPL-3.0-or-later
# Builds ldm_<version>_all.deb for Debian, Ubuntu, Linux Mint, Pop!_OS, Zorin, ...
set -eu
SRC=$(cd "$(dirname "$0")" && pwd); VER=$(cat "$SRC/VERSION"); OUT=${1:-$SRC}
STAGE=$(mktemp -d); trap 'rm -rf "$STAGE"' EXIT
"$SRC/install.sh" --system --prefix /usr --destdir "$STAGE" --no-hooks
install -d "$STAGE/DEBIAN"
sed "s/@VERSION@/$VER/" "$SRC/packaging/debian/control" > "$STAGE/DEBIAN/control"
install -m 755 "$SRC/packaging/debian/postinst" "$SRC/packaging/debian/postrm" "$STAGE/DEBIAN/"
install -m 644 "$SRC/packaging/debian/copyright" "$STAGE/usr/share/doc/ldm/copyright"
find "$STAGE" -type d -exec chmod 755 {} +
dpkg-deb --root-owner-group --build "$STAGE" "$OUT/ldm_${VER}_all.deb"
