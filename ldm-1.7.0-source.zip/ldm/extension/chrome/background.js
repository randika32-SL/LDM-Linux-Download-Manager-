// Copyright (C) 2026 SL_Linux
// SPDX-License-Identifier: GPL-3.0-or-later
// LDM Integration - sends browser downloads to Linux Download Manager.
const HOST = "org.ldm.host";
const FILE_TYPES = ("zip rar 7z tar gz gzip iso img msi exe doc docx pdf ppt pptx xls xlsx txt " +
  "mp3 wav wma aac m4a ogg aif mp4 mkv avi mov flv wmv webm 3gp m4v ts").split(" ");
const DEFAULTS = { enabled: true, minSizeMB: 0, extensions: "", sendCookies: true,
                   showButton: true, grabInline: true };
const action = chrome.action || chrome.browserAction;
const fmtCache = new Map();
const VIDEO_SITES = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|vimeo\.com|dailymotion\.com|twitch\.tv|tiktok\.com|facebook\.com|fb\.watch|instagram\.com|x\.com|twitter\.com|soundcloud\.com|bilibili\.com|reddit\.com)$/i;
const COOKIE_SITES = /(^|\.)(facebook\.com|fb\.watch|instagram\.com)$/i;   // need a login for stories/private videos
const isHttp = (u) => /^https?:\/\//i.test(u || "");
const hostOf = (u) => { try { return new URL(u).hostname; } catch (e) { return ""; } };
let lastCtx = null;   // the video the user right-clicked, reported by the page script

function notify(message) {
  try {
    chrome.notifications.create({ type: "basic", iconUrl: "icons/icon48.png", title: "LDM", message });
  } catch (e) { /* notifications are optional */ }
}
const EXT_RE = new RegExp("^https?://[^?#]*\\.(?:" + FILE_TYPES.join("|") + ")(?:[?#].*)?$", "i");

const getCfg = () => new Promise((r) => chrome.storage.local.get(DEFAULTS, r));

function native(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendNativeMessage(HOST, msg, (resp) => {
      if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
      else resolve(resp || { ok: false, error: "no response from LDM host" });
    });
  });
}

// ---- How we reach LDM -------------------------------------------------------
// 1) local link to a running LDM (works in every browser)   2) native messaging (can start LDM)
// 3) ldm:// link, which makes the desktop start LDM and open its Add dialog.
const PORTS = [38477, 38478, 38479, 38480, 38481];
const NO_HOST = /No such native|not found|Native host has exited|Specified native|forbidden/i;
let lastPort = null;

async function viaHttp(action, body, timeoutMs) {
  const order = lastPort ? [lastPort, ...PORTS.filter((p) => p !== lastPort)] : PORTS;
  for (const port of order) {
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), timeoutMs);
      const get = action === "ping";
      const r = await fetch("http://127.0.0.1:" + port + "/" + action, {
        method: get ? "GET" : "POST",
        headers: get ? {} : { "Content-Type": "application/json" },
        body: get ? undefined : JSON.stringify(body || {}),
        signal: ctl.signal,
      });
      clearTimeout(timer);
      const j = await r.json();
      lastPort = port;
      return j;
    } catch (e) { /* not listening on this port */ }
  }
  return null;
}

async function transport(action, payload, httpTimeout) {
  let r = await viaHttp(action, payload, httpTimeout);
  if (r) return Object.assign({ via: "http" }, r);
  r = await native(Object.assign({ action }, payload));
  if (r.ok || (r.error && !NO_HOST.test(r.error))) return Object.assign({ via: "native" }, r);
  return { ok: false, noTransport: true, error: r.error };
}

function launchScheme(url, referer, kind, quality) {
  let u = "ldm://start";
  if (url) {
    u = "ldm://add?url=" + encodeURIComponent(url) +
      (referer ? "&referer=" + encodeURIComponent(referer) : "") +
      (kind ? "&kind=" + kind : "") + (quality ? "&quality=" + encodeURIComponent(quality) : "");
  }
  chrome.tabs.create({ url: u, active: true }, () => void chrome.runtime.lastError);
}

function cookieHeader(url) {
  return new Promise((resolve) => {
    try {
      chrome.cookies.getAll({ url }, (list) =>
        resolve((list || []).map((c) => c.name + "=" + c.value).join("; ")));
    } catch (e) { resolve(""); }
  });
}

function flash(text, color) {
  try {
    action.setBadgeBackgroundColor({ color });
    action.setBadgeText({ text });
    setTimeout(() => action.setBadgeText({ text: "" }), 2500);
  } catch (e) { /* badge is cosmetic */ }
}

async function sendToLdm(url, referer, kind, quality, extra) {
  extra = extra || {};
  const cfg = await getCfg();
  // Plain downloads send the site's cookies; video pages only for sites that need a login.
  const wantCookie = cfg.sendCookies && (!kind || COOKIE_SITES.test(hostOf(url)));
  const cookie = wantCookie ? await cookieHeader(url) : "";
  let res = await transport("add", { url, referer: referer || "", cookie,
                                     kind: kind || "", quality: quality || "",
                                     ua: extra.ua || "", title: extra.title || "" }, 3000);
  if (!res.ok && res.noTransport) {           // LDM not running and no launcher: start it by link
    launchScheme(url, referer, kind, quality);
    res = { ok: true, via: "scheme", launched: true };
  }
  flash(res.ok ? "OK" : "!", res.ok ? "#2e9e5b" : "#c0392b");
  if (!res.ok) notify("Could not send this to LDM: " + (res.error || "unknown error"));
  return res;
}

function wanted(cfg, item) {
  const url = item.url || "";
  if (!/^https?:\/\//i.test(url)) return false;
  if (item.byExtensionId) return false;
  if (cfg.minSizeMB > 0 && item.fileSize > 0 && item.fileSize < cfg.minSizeMB * 1048576) return false;
  const list = cfg.extensions.split(/[\s,;]+/).map((x) => x.replace(/^\./, "").toLowerCase()).filter(Boolean);
  if (list.length) {
    const name = (item.filename || url.split("?")[0]).toLowerCase();
    const ext = name.includes(".") ? name.split(".").pop() : "";
    if (!list.includes(ext)) return false;
  }
  return true;
}

chrome.downloads.onCreated.addListener(async (item) => {
  const cfg = await getCfg();
  if (!cfg.enabled || !wanted(cfg, item)) return;
  if (item.state && item.state !== "in_progress") return;
  // Hold the browser's own download until LDM confirms it has the link.
  chrome.downloads.pause(item.id, () => void chrome.runtime.lastError);
  const res = await sendToLdm(item.url, item.referrer);
  if (res.ok) {
    chrome.downloads.cancel(item.id, () => {
      void chrome.runtime.lastError;
      chrome.downloads.erase({ id: item.id }, () => void chrome.runtime.lastError);
    });
  } else {
    chrome.downloads.resume(item.id, () => void chrome.runtime.lastError);   // fall back to the browser
  }
});

// ---- Files the browser would normally open itself (PDF, MP4, MP3, TXT, ...):
// ask the server's answer to be treated as an attachment so the download is captured.
async function syncInlineRule() {
  const cfg = await getCfg();
  const on = cfg.enabled && cfg.grabInline;
  const dnr = chrome.declarativeNetRequest;
  if (dnr && dnr.updateDynamicRules) {
    const rule = {
      id: 1, priority: 1,
      action: { type: "modifyHeaders",
                responseHeaders: [{ header: "content-disposition", operation: "set", value: "attachment" }] },
      condition: { regexFilter: EXT_RE.source, isUrlFilterCaseSensitive: false, resourceTypes: ["main_frame"] },
    };
    dnr.updateDynamicRules({ removeRuleIds: [1], addRules: on ? [rule] : [] }, () => void chrome.runtime.lastError);
  }
}
if (!(chrome.declarativeNetRequest && chrome.declarativeNetRequest.updateDynamicRules) &&
    chrome.webRequest && chrome.webRequest.onHeadersReceived) {
  chrome.webRequest.onHeadersReceived.addListener(async (details) => {      // Firefox (blocking)
    const cfg = await getCfg();
    if (!cfg.enabled || !cfg.grabInline || !EXT_RE.test(details.url)) return {};
    const headers = (details.responseHeaders || []).filter((h) => h.name.toLowerCase() !== "content-disposition");
    headers.push({ name: "Content-Disposition", value: "attachment" });
    return { responseHeaders: headers };
  }, { urls: ["<all_urls>"], types: ["main_frame"] }, ["blocking", "responseHeaders"]);
}
syncInlineRule();
chrome.runtime.onStartup && chrome.runtime.onStartup.addListener(syncInlineRule);
chrome.storage.onChanged.addListener(syncInlineRule);

chrome.runtime.onInstalled.addListener(() => {
  syncInlineRule();
  chrome.contextMenus.create({
    id: "ldm-link", title: "Download with LDM", contexts: ["link", "video", "audio"],
  });
  chrome.contextMenus.create({
    id: "ldm-video", title: "Download this video with LDM", contexts: ["page", "link"],
  });
});

// Decide what a right-click should download. Video players expose a blob: address that no
// downloader can use, so we fall back to the address of the video page the page script gave us.
function resolveTarget(info, tab, forceVideo) {
  const page = info.pageUrl || (tab && tab.url) || "";
  const fresh = lastCtx && Date.now() - lastCtx.t < 15000 && tab && lastCtx.tabId === tab.id;
  const ctx = fresh ? lastCtx.url : "";
  const media = info.mediaType === "video" || info.mediaType === "audio";
  let t = null;
  if (media && isHttp(ctx)) t = { url: ctx, kind: "video" };
  else if (isHttp(info.linkUrl)) t = { url: info.linkUrl, referer: page, kind: VIDEO_SITES.test(hostOf(info.linkUrl)) ? "video" : "" };
  else if (isHttp(info.srcUrl)) t = { url: info.srcUrl, referer: page, kind: "" };      // a real file address
  else if (isHttp(ctx)) t = { url: ctx, kind: "video" };
  else if (isHttp(page)) t = { url: page, kind: "video" };
  if (t && forceVideo) t.kind = "video";
  return t;
}

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const t = resolveTarget(info, tab, info.menuItemId === "ldm-video");
  if (!t) { notify("There is nothing to download here."); return; }
  sendToLdm(t.url, t.referer || "", t.kind || "", "");
});

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg) return false;
  if (msg.type === "ctx") {                   // page script: which video was right-clicked
    lastCtx = { url: msg.url || "", t: Date.now(), tabId: sender && sender.tab && sender.tab.id };
    return false;
  }
  if (msg.type === "ping") {                  // is a running LDM reachable right now?
    viaHttp("ping", null, 1500).then((r) => reply(r || { ok: false }));
    return true;
  }
  if (msg.type === "status") {                // for the popup: report each way of reaching LDM
    Promise.all([viaHttp("ping", null, 1500), native({ action: "ping" })])
      .then(([http, nat]) => reply({ http, native: nat }));
    return true;
  }
  if (msg.type === "launch") { launchScheme(); reply({ ok: true }); return false; }
  if (msg.type === "formats" && /^https?:/i.test(msg.url || "")) {
    const key = msg.url + "|" + (msg.referer || "");
    const hit = fmtCache.get(key);
    if (hit && Date.now() - hit.t < 300000) { reply(hit.res); return true; }
    transport("formats", { url: msg.url, referer: msg.referer || "", ua: msg.ua || "" }, 100000).then((res) => {
      if (res.noTransport) res = { ok: false, notRunning: true, error: "LDM is not running." };
      if (res.ok) fmtCache.set(key, { t: Date.now(), res });
      reply(res);
    });
    return true;
  }
  if (msg.type === "video" && /^https?:/i.test(msg.url || "")) {
    sendToLdm(msg.url, "", "video", msg.quality || "", { title: sender && sender.tab && sender.tab.title }).then(reply);
    return true;
  }
  if (msg.type === "streams") {               // media the page has loaded (for sites without a known extractor)
    const tabId = sender && sender.tab && sender.tab.id;
    listStreams(tabId, msg.src, sender && sender.url).then((items) =>
      reply({ ok: true, count: items.length, items,
              page: { url: sender && sender.tab && sender.tab.url, title: sender && sender.tab && sender.tab.title } }));
    return true;
  }
  if (msg.type === "stream" && msg.entry && /^https?:/i.test(msg.entry.url || "")) {
    const e = msg.entry;                       // HLS/DASH go through the video extractor, plain files straight through
    sendToLdm(e.url, e.referer || "", e.kind === "file" ? "" : "video", msg.quality || "",
              { ua: e.ua || "", title: sender && sender.tab && sender.tab.title }).then(reply);
    return true;
  }
  return false;
});


// ---- Stream sniffer ------------------------------------------------------------
// Sites with several "servers" load each one as an embedded player page whose JavaScript
// builds the real video address (an HLS/DASH playlist or an MP4, usually token-protected and
// checked against the embed page's Referer). The address never appears in the page's HTML,
// but the browser has to request it, so we watch the requests (read-only) and remember them.
const MEDIA_EXT = /\.(m3u8|mpd|mp4|m4v|webm|mkv|mov|flv|f4v|mp3|m4a|ogg|oga|wav)(?:$|[?#])/i;
const SEGMENT_RE = /\.(ts|m4s|m4f|cmfv|cmfa|aac|vtt|webvtt|key)(?:$|[?#])|(?:seg|segment|chunk|frag|part)[-_]?\d+/i;
const MEDIA_CTYPE = /^(video\/(mp4|webm|x-matroska|quicktime|x-flv|ogg)|audio\/(mpeg|mp4|x-m4a|ogg|wav|x-wav|webm)|application\/(vnd\.apple\.mpegurl|x-mpegurl|dash\+xml)|audio\/(x-)?mpegurl)/i;
const VARIANT_RE = /(chunklist|\/(?:v|video|index|stream|playlist|media)[-_]?\d+[-_.\/]|[-_\/]\d{3,4}p?\.m3u8|\/\d{3,4}p?\/)/i;
const MAX_PER_TAB = 40, MIN_FILE_BYTES = 1000000;
const tabStreams = new Map();     // tabId -> Map(key -> entry)
const reqHeaders = new Map();     // requestId -> {referer, origin, ua}
const session = chrome.storage && chrome.storage.session;
const ownPort = /^https?:\/\/127\.0\.0\.1:384(?:7[7-9]|8[01])\//;     // LDM's own local link (ports 38477-38481)

const streamKey = (url) => { try { const u = new URL(url); return u.origin + u.pathname; } catch (e) { return url; } };
function streamKind(url, ctype) {
  let path = url.toLowerCase();
  try { path = new URL(url).pathname.toLowerCase(); } catch (e) { /* keep raw */ }
  if (/\.m3u8$/.test(path) || /mpegurl/i.test(ctype || "")) return "hls";
  if (/\.mpd$/.test(path) || /dash\+xml/i.test(ctype || "")) return "dash";
  return "file";
}

async function loadTab(tabId) {
  if (tabStreams.has(tabId)) return tabStreams.get(tabId);
  const m = new Map();
  tabStreams.set(tabId, m);
  if (session) {                              // survive the extension's background being unloaded
    const r = await new Promise((res) => session.get("st" + tabId, res));
    for (const e of (r && r["st" + tabId]) || []) if (!m.has(streamKey(e.url))) m.set(streamKey(e.url), e);
  }
  return m;
}
function saveTab(tabId) {
  if (session && tabStreams.has(tabId)) session.set({ ["st" + tabId]: [...tabStreams.get(tabId).values()] });
}

async function rememberStream(tabId, e) {
  if (tabId == null || tabId < 0) return;
  const m = await loadTab(tabId);
  const key = streamKey(e.url);
  const old = m.get(key);
  m.set(key, Object.assign({}, old || {}, e, { t: Date.now(), size: e.size || (old && old.size) || 0 }));
  while (m.size > MAX_PER_TAB) m.delete(m.keys().next().value);
  saveTab(tabId);
}

function noteRequest(d) {
  if (d.tabId < 0 || ownPort.test(d.url)) return;
  const h = {};
  for (const x of d.requestHeaders || []) h[x.name.toLowerCase()] = x.value;
  const info = { referer: h.referer || d.documentUrl || d.originUrl || "", origin: h.origin || "", ua: h["user-agent"] || "" };
  if (reqHeaders.size > 400) reqHeaders.delete(reqHeaders.keys().next().value);
  reqHeaders.set(d.requestId, info);
  if (MEDIA_EXT.test(d.url) && !SEGMENT_RE.test(d.url)) {
    rememberStream(d.tabId, Object.assign({ url: d.url, kind: streamKind(d.url, ""), host: hostOf(d.url) }, info));
  }
}

function noteResponse(d) {
  if (d.tabId < 0 || ownPort.test(d.url)) return;
  let ctype = "", size = 0;
  for (const x of d.responseHeaders || []) {
    const n = x.name.toLowerCase();
    if (n === "content-type") ctype = x.value || "";
    else if (n === "content-range") { const m = /\/(\d+)\s*$/.exec(x.value || ""); if (m) size = Number(m[1]); }
    else if (n === "content-length" && !size) size = Number(x.value) || 0;
  }
  const byType = MEDIA_CTYPE.test(ctype);
  if (!byType && !(MEDIA_EXT.test(d.url) && !SEGMENT_RE.test(d.url))) return;
  if (SEGMENT_RE.test(d.url)) return;
  const kind = streamKind(d.url, ctype);
  if (kind === "file" && size && size < MIN_FILE_BYTES) {              // ads, previews, init segments
    loadTab(d.tabId).then((m) => { if (m.delete(streamKey(d.url))) saveTab(d.tabId); });   // drop the early guess
    return;
  }
  const info = reqHeaders.get(d.requestId) || {};
  rememberStream(d.tabId, Object.assign({ url: d.url, kind, ctype, size, host: hostOf(d.url) }, info));
}

(function hookWebRequest() {
  const wr = chrome.webRequest;
  if (!wr || !wr.onBeforeSendHeaders) return;
  const filter = { urls: ["http://*/*", "https://*/*"], types: ["media", "xmlhttprequest", "other"] };
  try { wr.onBeforeSendHeaders.addListener(noteRequest, filter, ["requestHeaders", "extraHeaders"]); }
  catch (e) { wr.onBeforeSendHeaders.addListener(noteRequest, filter, ["requestHeaders"]); }  // Firefox has no extraHeaders
  wr.onHeadersReceived.addListener(noteResponse, filter, ["responseHeaders"]);
})();

chrome.tabs.onRemoved.addListener((tabId) => { tabStreams.delete(tabId); if (session) session.remove("st" + tabId); });
chrome.tabs.onUpdated.addListener((tabId, change) => {      // a new page replaces the old one's streams
  if (change.status === "loading" && change.url) { tabStreams.set(tabId, new Map()); if (session) session.remove("st" + tabId); }
});

function describeStream(e) {
  const ext = (e.url.split("?")[0].split(".").pop() || "").toUpperCase();
  const label = e.kind === "hls" ? "HLS stream" : e.kind === "dash" ? "DASH stream" :
    (/^[A-Z0-9]{2,4}$/.test(ext) ? ext + " file" : "Video file");
  const mb = e.size ? (e.size / 1048576 >= 1024 ? (e.size / 1073741824).toFixed(2) + " GB" : Math.round(e.size / 1048576) + " MB") : "";
  return Object.assign({}, e, { label, sub: e.host + (mb ? "  \u00B7  " + mb : "") });
}

async function listStreams(tabId, src, frameUrl) {
  const m = tabId != null ? await loadTab(tabId) : new Map();
  let list = [...m.values()];
  if (src && /^https?:\/\//i.test(src) && !m.has(streamKey(src)) && !SEGMENT_RE.test(src)) {
    list.push({ url: src, kind: streamKind(src, ""), host: hostOf(src), referer: frameUrl || "", ua: "", t: 0 });
  }
  const masters = list.filter((e) => e.kind === "hls" && !VARIANT_RE.test(e.url));
  if (masters.length) list = list.filter((e) => e.kind !== "hls" || !VARIANT_RE.test(e.url));   // show the master, not its variants
  return list.sort((a, b) => b.t - a.t).map(describeStream);
}
