// Copyright (C) 2026 SL_Linux
// SPDX-License-Identifier: GPL-3.0-or-later
// Download button on video players (top-right of the video), with a quality menu.
(function () {
  if (window.__ldmOverlay) return;
  window.__ldmOverlay = true;
  const HIDE_MS = 2500;
  const FB = /(^|\.)facebook\.com$/i.test(location.hostname);
  // Sites yt-dlp has its own extractor for use "page mode"; everything else (anime/film sites with
  // several embedded servers, ...) uses "stream mode": the streams the browser actually loaded.
  const KNOWN = /(^|\.)(youtube\.com|youtu\.be|youtube-nocookie\.com|vimeo\.com|dailymotion\.com|twitch\.tv|facebook\.com)$/i.test(location.hostname);
  let hasStreams = false, lastPoll = 0, pageInfo = {};
  let host = null, wrap = null, btn = null, panel = null, curVideo = null;
  let enabled = true, panelOpen = false, overUi = false, panelFor = "", panelHref = "";
  const mouse = { x: -1, y: -1, t: 0 };

  const send = (msg, cb) => {
    try { chrome.runtime.sendMessage(msg, (r) => { void chrome.runtime.lastError; cb && cb(r); }); }
    catch (e) { cb && cb(undefined); }        // extension was reloaded while this page stayed open
  };
  chrome.storage.local.get({ showButton: true }, (c) => (enabled = c.showButton));
  chrome.storage.onChanged.addListener((ch) => { if (ch.showButton) enabled = ch.showButton.newValue; });

  const css = `
    .wrap{position:fixed;font:13px system-ui,sans-serif;transition:opacity .15s;}
    .btn{display:flex;align-items:center;gap:6px;cursor:pointer;border:0;color:#fff;background:rgba(27,95,184,.95);
         padding:6px 11px;border-radius:16px;font:600 12px system-ui,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.5);}
    .btn:hover{background:#2a74d6;}
    .panel{position:absolute;top:34px;right:0;min-width:230px;max-height:60vh;overflow:auto;background:#1e1e1e;color:#eee;
           border-radius:8px;box-shadow:0 6px 24px rgba(0,0,0,.6);padding:6px 0;}
    .hd{padding:6px 12px 8px;color:#9ab;font-size:11px;border-bottom:1px solid #333;max-width:300px;
        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .row{display:flex;justify-content:space-between;gap:18px;padding:7px 12px;cursor:pointer;}
    .row:hover{background:#2a74d6;}
    .sz{color:#aab;} .row:hover .sz{color:#fff;}
    .msg{padding:10px 12px;max-width:280px;line-height:1.35;color:#ddd;}
    .err{color:#ff9d8f;}
  `;

  function el(tag, cls, text) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  // ---- which address belongs to a given <video>? -----------------------------
  // YouTube & co: the page address. Facebook: a feed holds many videos, so find the
  // permalink of the post/reel/story the video sits in.
  const FB_LINK = /\/(watch\/?\?(?:[^#]*&)?v=\d+|reel\/\d+|[^\/?#]+\/videos\/(?:[^\/?#]+\/)?\d+|videos\/\d+|share\/[vr]\/[\w-]+|stories\/[^\/?#]+\/[\w=-]+|story\.php|permalink\.php|[^\/?#]+\/posts\/[\w-]+)/i;

  function cleanFb(href) {
    try {
      const u = new URL(href, location.href);
      if (!/(^|\.)facebook\.com$/i.test(u.hostname)) return null;
      const keep = new URLSearchParams();
      for (const k of ["v", "id", "story_fbid", "fbid"]) if (u.searchParams.has(k)) keep.set(k, u.searchParams.get(k));
      u.search = keep.toString();
      u.hash = "";
      return u.href;
    } catch (e) { return null; }
  }

  function fbTarget(video) {
    if (FB_LINK.test(location.pathname + location.search)) return cleanFb(location.href);   // on the video's own page
    for (let node = video, i = 0; node && node !== document.body && i < 30; node = node.parentElement, i++) {
      if (node.querySelectorAll("video").length > 1) break;       // container shared with other videos: ambiguous
      for (const a of node.querySelectorAll("a[href]")) {
        const h = a.getAttribute("href") || "";
        if (FB_LINK.test(h)) { const u = cleanFb(a.href); if (u) return u; }
      }
    }
    return cleanFb(location.href);
  }

  function targetUrl(video) { return FB && video ? fbTarget(video) : location.href; }

  // ---- which video is the user pointing at? -----------------------------------
  function visibleVideos() {
    const out = [];
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      const w = Math.min(r.right, innerWidth) - Math.max(r.left, 0);
      const h = Math.min(r.bottom, innerHeight) - Math.max(r.top, 0);
      if (r.width < 240 || r.height < 135 || w <= 0 || h <= 0) continue;
      out.push({ v, r, area: w * h });
    }
    return out;
  }
  const contains = (r, x, y) => x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;

  function pickVideo() {
    const vs = visibleVideos();
    if (!vs.length) return null;
    if (panelOpen || overUi) { const keep = vs.find((x) => x.v === curVideo); if (keep) return keep; }
    const hov = vs.filter((x) => contains(x.r, mouse.x, mouse.y)).sort((a, b) => b.area - a.area)[0];
    return hov || vs.sort((a, b) => b.area - a.area)[0];
  }

  // ---- UI -------------------------------------------------------------------
  function build() {
    host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;";
    const root = host.attachShadow({ mode: "open" });
    const st = document.createElement("style");
    st.textContent = css;
    root.appendChild(st);
    wrap = el("div", "wrap");
    wrap.style.opacity = "0";
    wrap.style.pointerEvents = "none";
    btn = el("button", "btn", "\u2B07  Download");
    btn.title = "Download this video with Linux Download Manager";
    btn.addEventListener("click", (e) => { e.stopPropagation(); e.preventDefault(); togglePanel(); });
    wrap.appendChild(btn);
    wrap.addEventListener("mouseenter", () => (overUi = true));
    wrap.addEventListener("mouseleave", () => (overUi = false));
    root.appendChild(wrap);
    (document.fullscreenElement || document.documentElement).appendChild(host);
  }

  function fmtSize(n) {
    if (!n) return "";
    const mb = n / 1048576;
    return mb >= 1024 ? (mb / 1024).toFixed(2) + " GB" : mb.toFixed(mb < 10 ? 1 : 0) + " MB";
  }

  function closePanel() {
    panelOpen = false;
    if (panel) { panel.remove(); panel = null; }
  }

  function renderMessage(text, isErr) {
    panel.textContent = "";
    panel.appendChild(el("div", "msg" + (isErr ? " err" : ""), text));
  }

  function startLdm() {
    renderMessage("Starting LDM... (allow the browser to open it if asked)");
    send({ type: "launch" });
    let tries = 0;
    const poll = () => {
      if (!panel) return;
      send({ type: "ping" }, (r) => {
        if (r && r.ok) { loadFormats(); return; }
        if (++tries > 20) { renderMessage("LDM did not start. Open it from the menu, then try again.", true); return; }
        setTimeout(poll, 1500);
      });
    };
    setTimeout(poll, 1500);
  }

  function togglePanel() {
    if (panelOpen) { closePanel(); return; }
    panelOpen = true;
    panelHref = location.href;
    panelFor = targetUrl(curVideo) || location.href;     // the address of the video under the button
    panel = el("div", "panel");
    wrap.appendChild(panel);
    if (KNOWN) loadFormats(); else loadStreams();
  }

  // ---- stream mode ------------------------------------------------------------
  function row2(left, right, onClick) {
    const row = el("div", "row");
    row.appendChild(el("span", "", left));
    row.appendChild(el("span", "sz", right || ""));
    row.addEventListener("click", (e) => { e.stopPropagation(); onClick(); });
    return row;
  }

  function sendStream(entry, quality) {
    renderMessage("Sending to LDM...");
    send({ type: "stream", entry, quality }, (r) => {
      renderMessage(r && r.ok ? "\u2713 Sent to LDM" : "Failed: " + ((r && r.error) || "LDM not reachable"), !(r && r.ok));
      setTimeout(closePanel, 1400);
    });
  }

  function loadStreams() {
    renderMessage("Looking for the video streams of this page...");
    send({ type: "streams", src: curVideo && curVideo.currentSrc }, (res) => {
      if (!panel) return;
      pageInfo = (res && res.page) || {};
      const items = (res && res.items) || [];
      hasStreams = items.length > 0;
      panel.textContent = "";
      panel.appendChild(el("div", "hd", items.length ? "Streams found - newest first" : "Streams"));
      if (!items.length) {
        panel.appendChild(el("div", "msg", "Nothing detected yet. Press play on the video (or switch to another server), then open this menu again."));
      }
      for (const e of items) {
        panel.appendChild(row2(e.label, e.sub, () => (e.kind === "file" ? sendStream(e, "") : loadStreamFormats(e))));
      }
      if (pageInfo.url) {
        panel.appendChild(row2("Let LDM analyze this page", "", () => {
          renderMessage("Sending to LDM...");
          send({ type: "video", url: pageInfo.url }, (r) => {
            renderMessage(r && r.ok ? "\u2713 Sent to LDM" : "Failed: " + ((r && r.error) || "LDM not reachable"), !(r && r.ok));
            setTimeout(closePanel, 1400);
          });
        }));
      }
    });
  }

  function loadStreamFormats(entry) {
    renderMessage("Reading the qualities of this stream...");
    send({ type: "formats", url: entry.url, referer: entry.referer, ua: entry.ua }, (res) => {
      if (!panel) return;
      if (res && res.notRunning) { renderMessage("LDM is not running. Start LDM, then try again.", true); return; }
      panel.textContent = "";
      const back = row2("\u2190 Back to streams", "", loadStreams);
      if (!res || !res.ok) {
        panel.appendChild(el("div", "msg err", "Could not read the qualities: " + ((res && res.error) || "no answer")));
        panel.appendChild(row2("Download best quality anyway", "", () => sendStream(entry, "Best available")));
        panel.appendChild(back);
        return;
      }
      panel.appendChild(el("div", "hd", entry.label + " - choose quality"));
      for (const it of res.items) panel.appendChild(row2(it.label, fmtSize(it.size), () => sendStream(entry, it.quality)));
      panel.appendChild(back);
    });
  }

  function loadFormats() {
    renderMessage("Reading available qualities...");
    const target = panelFor;
    send({ type: "formats", url: target }, (res) => {
      if (!panel || panelFor !== target) return;
      if (res && res.notRunning) {
        panel.textContent = "";
        panel.appendChild(el("div", "msg", "LDM is not running."));
        const row = el("div", "row");
        row.appendChild(el("span", "", "Start LDM"));
        row.addEventListener("click", (e) => { e.stopPropagation(); startLdm(); });
        panel.appendChild(row);
        return;
      }
      if (!res || !res.ok) {
        renderMessage("Could not read this video: " + ((res && res.error) || "no answer from the extension"), true);
        return;
      }
      panel.textContent = "";
      panel.appendChild(el("div", "hd", res.title || "Choose quality"));
      for (const it of res.items) {
        const row = el("div", "row");
        row.appendChild(el("span", "", it.label));
        row.appendChild(el("span", "sz", fmtSize(it.size)));
        row.addEventListener("click", (e) => {
          e.stopPropagation();
          renderMessage("Sending to LDM...");
          send({ type: "video", url: target, quality: it.quality }, (r) => {
            renderMessage(r && r.ok ? "\u2713 Sent to LDM" : "Failed: " + ((r && r.error) || "LDM not reachable"), !(r && r.ok));
            setTimeout(closePanel, 1400);
          });
        });
        panel.appendChild(row);
      }
    });
  }

  document.addEventListener("mousemove", (e) => { mouse.x = e.clientX; mouse.y = e.clientY; mouse.t = Date.now(); },
                            { capture: true, passive: true });

  // Close the quality menu when the user clicks elsewhere or presses Escape.
  document.addEventListener("mousedown", (e) => {
    if (panelOpen && host && !e.composedPath().includes(host)) closePanel();
  }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePanel(); }, true);

  // Remember which video was right-clicked so "Download with LDM" knows the right address.
  document.addEventListener("contextmenu", (e) => {
    const hit = visibleVideos().filter((x) => contains(x.r, e.clientX, e.clientY)).sort((a, b) => b.area - a.area)[0];
    send({ type: "ctx", url: hit ? targetUrl(hit.v) : "" });
  }, { capture: true, passive: true });

  function tick() {
    const pick = enabled && /^https?:/.test(location.href) ? pickVideo() : null;
    if (!pick) { if (host) { wrap.style.opacity = "0"; wrap.style.pointerEvents = "none"; closePanel(); } return; }
    curVideo = pick.v;
    if (!KNOWN && Date.now() - lastPoll > 2000) {
      lastPoll = Date.now();
      send({ type: "streams", src: curVideo.currentSrc }, (r) => { hasStreams = !!(r && r.count > 0); });
    }
    if (!KNOWN && !hasStreams && !panelOpen) { if (host) { wrap.style.opacity = "0"; wrap.style.pointerEvents = "none"; } return; }
    if (!host) build();
    const parent = document.fullscreenElement || document.documentElement;
    if (host.parentNode !== parent) parent.appendChild(host);
    if (panelOpen && panelHref !== location.href) closePanel();
    const r = pick.r;
    const bw = wrap.offsetWidth || 110;
    wrap.style.left = Math.max(4, Math.min(innerWidth - bw - 4, r.right - bw - 10)) + "px";
    wrap.style.top = Math.max(4, r.top + 10) + "px";
    const inside = contains(r, mouse.x, mouse.y);
    const show = panelOpen || overUi || (inside && Date.now() - mouse.t < HIDE_MS);
    wrap.style.opacity = show ? "1" : "0";
    wrap.style.pointerEvents = show ? "auto" : "none";
    if (!show && panelOpen) closePanel();
  }
  (function loop() {                         // poll fast only while the page has a video
    tick();
    setTimeout(loop, document.querySelector("video") ? 150 : 1000);
  })();
})();
