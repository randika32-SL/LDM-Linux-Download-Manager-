// Copyright (C) 2026 SL_Linux
// SPDX-License-Identifier: GPL-3.0-or-later
const DEFAULTS = { enabled: true, minSizeMB: 0, extensions: "", sendCookies: true, showButton: true, grabInline: true };
const $ = (id) => document.getElementById(id);

chrome.storage.local.get(DEFAULTS, (cfg) => {
  $("enabled").checked = cfg.enabled;
  $("sendCookies").checked = cfg.sendCookies;
  $("showButton").checked = cfg.showButton;
  $("grabInline").checked = cfg.grabInline;
  $("ver").textContent = "Extension v" + chrome.runtime.getManifest().version;
  $("minSizeMB").value = cfg.minSizeMB;
  $("extensions").value = cfg.extensions;
});

function save() {
  chrome.storage.local.set({
    enabled: $("enabled").checked,
    sendCookies: $("sendCookies").checked,
    showButton: $("showButton").checked,
    grabInline: $("grabInline").checked,
    minSizeMB: Math.max(0, Number($("minSizeMB").value) || 0),
    extensions: $("extensions").value,
  });
}
["enabled", "sendCookies", "showButton", "grabInline", "minSizeMB", "extensions"].forEach((id) =>
  $(id).addEventListener("change", save));

$("test").addEventListener("click", () => {
  const s = $("status");
  s.className = ""; s.textContent = "Contacting LDM...";
  chrome.runtime.sendMessage({ type: "status" }, (res) => {
    const mine = chrome.runtime.getManifest().version;
    const http = res && res.http, nat = res && res.native;
    if (http && http.ok) {
      const minor = (v) => String(v).split(".").slice(0, 2).join(".");   // patch releases need no reload
      if (minor(http.version) !== minor(mine)) {
        s.className = "bad";
        s.textContent = "LDM is v" + http.version + " but this extension is v" + mine +
          ". Reload the extension (chrome://extensions or about:debugging) after updating LDM.";
      } else { s.className = "ok"; s.textContent = "Connected to LDM " + http.version + " (local link)."; }
    } else if (nat && nat.ok) {
      s.className = "ok";
      s.textContent = "LDM is not running right now, but the browser can start it. Downloads will work.";
    } else {
      s.className = "bad";
      s.textContent = "LDM is not running. Click 'Start LDM' (allow your browser to open it). " +
        "Tip: in LDM > Options enable 'Start LDM when I log in'.";
    }
  });
});

$("launch").addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "launch" }, () => void chrome.runtime.lastError);
});

$("video").addEventListener("click", () => {
  const s = $("status");
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const url = tabs && tabs[0] && tabs[0].url;
    if (!url || !/^https?:/i.test(url)) { s.className = "bad"; s.textContent = "Open a video page first."; return; }
    chrome.runtime.sendMessage({ type: "video", url }, (res) => {
      const ok = res && res.ok;
      s.className = ok ? "ok" : "bad";
      s.textContent = ok ? "Sent to LDM - choose the quality there." : "Failed: " + ((res && res.error) || "LDM not reachable");
    });
  });
});
